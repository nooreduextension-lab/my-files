// ===============================
// LMS Smart Lesson Planner
// Background Service Worker — v4.0
//
// Intentionally minimal. All generation logic lives in content.js.
// This file exists only because MV3 requires a service_worker declaration.
// ===============================

self.addEventListener("install",  ()  => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));

chrome.runtime.onInstalled.addListener(() => {
  console.log("LMS Smart Lesson Planner installed.");
});
