// ===============================
// LMS Smart Lesson Planner
// Popup — v5.2  (Pure Supabase OTP Auth)
// ===============================

// -------- BROWSER API SHIM --------
const api = (() => {
  if (typeof browser !== "undefined" && browser.runtime) return browser;
  return {
    runtime: chrome.runtime,
    tabs: chrome.tabs,
    storage: {
      local: {
        get:    (keys)  => new Promise((res) => chrome.storage.local.get(keys, res)),
        set:    (items) => new Promise((res) => chrome.storage.local.set(items, res)),
        remove: (keys)  => new Promise((res) => chrome.storage.local.remove(keys, res)),
      },
    },
  };
})();

// -------- CONFIG --------
const SUPABASE_URL      = "https://rznegxkfwwtqkytkoljs.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6bmVneGtmd3d0cWt5dGtvbGpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIyNTI3ODgsImV4cCI6MjA4NzgyODc4OH0.bc7hSJF9DUmoNG0k54vWge_tQ4fgGWLi_xEn8YXX5ug";
const CHECKOUT_URL      = "https://buy.polar.sh/polar_cl_SZLRHuavlxx7ioEO4FZp4SvsZ8CXqHabPo7ZT0RNsD2";
const REPORT_URL        = "https://my-files-tau.vercel.app";
const OTP_TTL_SECONDS = 180;
const CHECK_EMAIL_STATUS_URL = `${SUPABASE_URL}/functions/v1/check-email-status`;

// -------- SUPABASE HELPERS --------

async function supabase(path, method = "GET", body = null, token = null) {
  const headers = {
    "apikey":        SUPABASE_ANON_KEY,
    "Authorization": `Bearer ${token || SUPABASE_ANON_KEY}`,
    "Content-Type":  "application/json",
  };
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${SUPABASE_URL}${path}`, opts);
  const text = await res.text();
  try { return { ok: res.ok, status: res.status, data: JSON.parse(text) }; }
  catch { return { ok: res.ok, status: res.status, data: text }; }
}

async function getUser(accessToken) {
  return supabase("/auth/v1/user", "GET", null, accessToken);
}

async function signOut(accessToken) {
  return supabase("/auth/v1/logout", "POST", null, accessToken);
}

// -------- SESSION STORAGE --------

async function saveSession(session) {
  await api.storage.local.set({
    sb_access_token:  session.access_token,
    sb_refresh_token: session.refresh_token,
    sb_user_email:    session.user?.email || "",
    sb_user_id:       session.user?.id    || "",
  });
}

function isValidSupabaseSession(session) {
  return Boolean(
    session &&
    typeof session.access_token === "string" &&
    session.access_token.length > 0 &&
    session.user &&
    typeof session.user.email === "string" &&
    session.user.email.length > 0
  );
}

function setWelcomeStatus(email, type = "info") {
  const currentScreen = ["auth-screen", "verify-screen", "app-screen"]
    .find((id) => document.getElementById(id).style.display !== "none");
  const map = {
    "auth-screen": "auth-status",
    "verify-screen": "verify-status",
    "app-screen": "app-status",
  };
  const el = document.getElementById(map[currentScreen] || "app-status");
  el.className = type;
  el.replaceChildren();
  const wrap = document.createElement("span");
  wrap.className = "welcome-split";
  const ar = document.createElement("span");
  ar.className = "welcome-ar";
  ar.textContent = "مـــــــــــرحــــــــــبـــــــــــا";
  const emailEl = document.createElement("span");
  emailEl.className = "welcome-email";
  emailEl.textContent = email;
  wrap.appendChild(ar);
  wrap.appendChild(emailEl);
  el.appendChild(wrap);
}

async function clearSession() {
  await api.storage.local.remove([
    "sb_access_token", "sb_refresh_token",
    "sb_user_email",   "sb_user_id",
    "user_plan",
  ]);
}

async function getSession() {
  return api.storage.local.get([
    "sb_access_token", "sb_refresh_token",
    "sb_user_email",   "sb_user_id",
  ]);
}

async function setPendingAuth(email, createUser) {
  await api.storage.local.set({
    sb_pending_email: email,
    sb_pending_create_user: createUser,
    sb_otp_sent_at: Date.now()
  });
}

// -------- UI HELPERS --------

function setStatus(msg, type = "error") {
  const currentScreen = ["auth-screen", "verify-screen", "app-screen"]
    .find((id) => document.getElementById(id).style.display !== "none");
  const map = {
    "auth-screen": "auth-status",
    "verify-screen": "verify-status",
    "app-screen": "app-status",
  };
  const el = document.getElementById(map[currentScreen] || "auth-status");
  el.textContent = msg;
  el.className = type;
}

function showScreen(name) {
  ["auth-screen", "verify-screen", "app-screen"].forEach(id => {
    document.getElementById(id).style.display = id === name ? "" : "none";
  });
  ["auth-status", "verify-status", "app-status"].forEach((id) => {
    const el = document.getElementById(id);
    el.textContent = "";
    el.className = "";
  });
}

function setLoading(btnId, loading) {
  const btn = document.getElementById(btnId);
  if (!btn) return;
  btn.disabled = loading;
  btn.style.opacity = loading ? "0.6" : "";
}

async function openTab(url) {
  try { await api.tabs.create({ url }); }
  catch (e) { window.open(url, "_blank"); }
}

function withTimeout(promise, ms = 12000) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error("REQUEST_TIMEOUT")), ms))
  ]);
}

async function returnToAuthScreen() {
  clearInterval(_otpTimerInterval);
  document.getElementById("otp-input").value = "";
  document.getElementById("otp-timer").textContent = "";
  document.getElementById("btn-check-verify").disabled = false;
  await api.storage.local.remove(["sb_pending_email", "sb_pending_create_user", "sb_otp_sent_at"]);
  showScreen("auth-screen");
}

async function clearPendingAuth() {
  clearInterval(_otpTimerInterval);
  document.getElementById("otp-input").value = "";
  document.getElementById("otp-timer").textContent = "";
  document.getElementById("btn-check-verify").disabled = false;
  await api.storage.local.remove(["sb_pending_email", "sb_pending_create_user", "sb_otp_sent_at"]);
}

async function isRegisteredEmail(email) {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/users?email=eq.${encodeURIComponent(email)}&select=email&limit=1`,
    {
      headers: {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
      }
    }
  );
  if (!res.ok) return null;
  const rows = await res.json().catch(() => []);
  return Array.isArray(rows) && rows.length > 0;
}

async function checkEmailStatus(email) {
  const res = await fetch(CHECK_EMAIL_STATUS_URL, {
    method: "POST",
    headers: {
      "apikey": SUPABASE_ANON_KEY,
      "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email }),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) return { error: data?.error || "check_email_status_failed" };
  return data;
}

// -------- TABS (Login / Signup) --------

let currentMode = "login";

document.getElementById("tab-login").addEventListener("click", () => {
  currentMode = "login";
  document.getElementById("tab-login").classList.add("active");
  document.getElementById("tab-signup").classList.remove("active");
  document.getElementById("btn-submit").textContent = "تسجيل الدخول";
  document.getElementById("moe-warning").style.visibility = "hidden";
  clearPendingAuth().catch(() => {});
  setStatus("");
});

document.getElementById("tab-signup").addEventListener("click", () => {
  currentMode = "signup";
  document.getElementById("tab-signup").classList.add("active");
  document.getElementById("tab-login").classList.remove("active");
  document.getElementById("btn-submit").textContent = "إنشاء حساب";
  document.getElementById("moe-warning").style.visibility = "visible";
  clearPendingAuth().catch(() => {});
  setStatus("");
});

// -------- MAIN AUTH BUTTON --------
// Both login and signup send an OTP — only difference is create_user flag

document.getElementById("btn-submit").addEventListener("click", async () => {
  const rawEmail = document.getElementById("auth-email").value;
  const email = rawEmail.trim().toLowerCase();

  if (!email.includes("@") || !email.includes(".")) {
    setStatus("يرجى إدخال بريد إلكتروني صحيح.", "error");
    return;
  }

  setLoading("btn-submit", true);
  setStatus(currentMode === "login" ? "جارٍ التحقق..." : "جارٍ الإرسال...", "info");

  try {
    if (currentMode === "login") {
      const statusData = await checkEmailStatus(email);
      if (!statusData) {
        setStatus("تعذّر التحقق حالياً. حاول مجدداً.", "error");
        return;
      }
      if (statusData.error) {
        setStatus(`تعذّر التحقق حالياً (${statusData.error}).`, "error");
        return;
      }
      if (statusData.status === "not_registered") {
        setStatus("البريد غير مسجل", "error");
        return;
      }
      if (statusData.status === "not_verified") {
        setStatus("البريد غير مؤكد. يرجى تأكيد بريدك أولاً.", "error");
        return;
      }
      if (statusData.status !== "verified") {
        setStatus("تعذّر التحقق حالياً. حاول مجدداً.", "error");
        return;
      }
      const plan = (await fetchUserPlan(email, SUPABASE_ANON_KEY)) || "free";
      await api.storage.local.set({
        sb_access_token: "email_verified",
        sb_refresh_token: "",
        sb_user_email: email,
        sb_user_id: statusData.user_id || "",
        user_plan: plan,
      });
      showScreen("app-screen");
      showPlanUI(plan);
      if (plan === "premium") setStatus("✦ Premium plan active", "success");
      else setWelcomeStatus(email, "info");
      return;
    }
    await handleOtp(email, currentMode === "signup");
  } finally {
    setLoading("btn-submit", false);
  }
});

// -------- SEND OTP --------

async function handleOtp(email, createUser) {
  const { ok, status, data } = await supabase("/auth/v1/otp", "POST", {
    email,
    create_user: createUser,
  });

  if (!ok) {
    const msg = data?.msg || data?.message || "";
    if (status === 429) {
      setStatus("تم إرسال طلبات كثيرة. انتظر قليلاً ثم أعد المحاولة.", "error");
      return;
    }
    if (!createUser && (msg.toLowerCase().includes("not found") || msg.toLowerCase().includes("no user"))) {
      setStatus("البريد غير مسجّل. يرجى إنشاء حساب أولاً.", "error");
    } else {
      setStatus("تعذّر إرسال الرمز. تأكد من البريد وتحقق من مجلد Spam ثم أعد المحاولة.", "error");
    }
    return;
  }

  await setPendingAuth(email, createUser);
  showScreen("verify-screen");
  setStatus("تم إرسال الرمز إلى بريدك الإلكتروني.", "info");
  startOtpTimer(OTP_TTL_SECONDS, Date.now());
}

async function fetchUserPlan(email, token) {
  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/users?email=eq.${encodeURIComponent(email)}&select=plan`,
      {
        headers: {
          "apikey": SUPABASE_ANON_KEY,
          "Authorization": `Bearer ${token || SUPABASE_ANON_KEY}`,
        }
      }
    );
    const rows = await res.json();
    if (rows?.length > 0) return rows[0].plan || "free";
  } catch (e) { /* non-fatal */ }
  return "free";
}

// -------- OTP COUNTDOWN TIMER --------

let _otpTimerInterval = null;

function startOtpTimer(seconds, sentAt = Date.now()) {
  clearInterval(_otpTimerInterval);
  const timerEl = document.getElementById("otp-timer");
  const verifyBtn = document.getElementById("btn-check-verify");
  let remaining = seconds;

  function tick() {
    if (remaining <= 0) {
      clearInterval(_otpTimerInterval);
      timerEl.textContent = "انتهت صلاحية الرمز. يرجى المحاولة مرة أخرى.";
      timerEl.style.color = "#ef4444";
      verifyBtn.disabled = true;
      return;
    }
    const m = Math.floor(remaining / 60).toString().padStart(2, "0");
    const s = (remaining % 60).toString().padStart(2, "0");
    timerEl.textContent = `ينتهي الرمز خلال: ${m}:${s}`;
    timerEl.style.color = remaining <= 30 ? "#ef4444" : "#6b7280";
    remaining--;
  }
  tick();
  _otpTimerInterval = setInterval(tick, 1000);
}

// -------- OTP VERIFY BUTTON --------

document.getElementById("btn-check-verify").addEventListener("click", async () => {
  const otp = (document.getElementById("otp-input")?.value || "").replace(/\s+/g, "").trim();

  if (!otp || otp.length < 4) {
    setStatus("يرجى إدخال رمز التحقق.", "error");
    return;
  }

  setLoading("btn-check-verify", true);
  setStatus("جارٍ التحقق...", "info");

  const stored = await api.storage.local.get(["sb_pending_email", "sb_pending_create_user"]);
  const email  = stored.sb_pending_email;
  const isSignupFlow = Boolean(stored.sb_pending_create_user);

  if (!email) {
    setStatus("يرجى المحاولة من جديد.", "error");
    setLoading("btn-check-verify", false);
    return;
  }

  try {
    // Strict verification type based on original flow (login vs signup)
    const verifyType = isSignupFlow ? "signup" : "email";
    const result = await withTimeout(supabase("/auth/v1/verify", "POST", {
      type:  verifyType,
      email: email,
      token: otp,
    }));

    const { ok, data, status } = result;

    if (!ok || !isValidSupabaseSession(data)) {
      const msg = data?.error_description || data?.msg || data?.message || "";
      if (status === 429) {
        setStatus("محاولات كثيرة. انتظر قليلاً قبل المحاولة مرة أخرى.", "error");
        return;
      }
      if (msg.toLowerCase().includes("expired")) {
        setStatus("انتهت صلاحية الرمز. ارجع وسجّل الدخول مرة أخرى.", "error");
        return;
      }
      setStatus(msg || "رمز غير صحيح أو منتهي الصلاحية.", "error");
      return;
    }

    clearInterval(_otpTimerInterval);
    await saveSession(data);
    await api.storage.local.remove(["sb_pending_email", "sb_pending_create_user", "sb_otp_sent_at"]);
    await loadAppScreen(data.access_token, data.user?.email || email);
  } catch (e) {
    if (e?.message === "REQUEST_TIMEOUT") {
      setStatus("انتهت مهلة التحقق. يرجى المحاولة مرة أخرى.", "error");
    } else {
      setStatus("تعذّر التحقق حالياً. حاول مجدداً.", "error");
    }
  } finally {
    setLoading("btn-check-verify", false);
  }
});

document.getElementById("btn-back-login").addEventListener("click", async () => {
  await returnToAuthScreen();
});

// -------- APP SCREEN --------

async function loadAppScreen(accessToken, email) {
  const plan = await fetchUserPlan(email, accessToken);
  await api.storage.local.set({ user_plan: plan });
  showScreen("app-screen");
  showPlanUI(plan);
  if (plan === "premium") setStatus("✦ Premium plan active", "success");
  else setWelcomeStatus(email, "info");
}

function showPlanUI(plan) {
  const isPremium = plan === "premium";
  document.getElementById("upgrade").style.display    = isPremium ? "none"  : "block";
  document.getElementById("cancel-sub").style.display = isPremium ? "block" : "none";
}

// -------- LOGOUT --------

document.getElementById("btn-logout").addEventListener("click", async () => {
  const { sb_access_token } = await getSession();
  if (sb_access_token && sb_access_token !== "email_verified") await signOut(sb_access_token).catch(() => {});
  await clearSession();
  showScreen("auth-screen");
  currentMode = "login";
  document.getElementById("tab-login").classList.add("active");
  document.getElementById("tab-signup").classList.remove("active");
  document.getElementById("btn-submit").textContent = "تسجيل الدخول";
  document.getElementById("auth-email").value = "";
});

// -------- UPGRADE --------

document.getElementById("upgrade").addEventListener("click", async () => {
  const { sb_user_email, sb_user_id } = await getSession();
  if (!sb_user_email) { setStatus("يرجى تسجيل الدخول أولاً.", "error"); return; }
  const params = new URLSearchParams();
  params.set("prefill_email", sb_user_email);
  if (sb_user_id) params.set("metadata[user_id]", sb_user_id);
  await openTab(CHECKOUT_URL + "?" + params.toString());
});

// -------- CANCEL SUBSCRIPTION --------

document.getElementById("cancel-sub").addEventListener("click", () => {
  document.getElementById("confirm-overlay").classList.add("visible");
});
document.getElementById("btn-keep").addEventListener("click", () => {
  document.getElementById("confirm-overlay").classList.remove("visible");
});
document.getElementById("btn-confirm-cancel").addEventListener("click", async () => {
  document.getElementById("confirm-overlay").classList.remove("visible");
  const { sb_user_email, sb_access_token } = await getSession();
  if (!sb_user_email) return;
  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/users?email=eq.${encodeURIComponent(sb_user_email)}`,
      {
        method: "PATCH",
        headers: {
          "apikey":        SUPABASE_ANON_KEY,
          "Authorization": `Bearer ${sb_access_token}`,
          "Content-Type":  "application/json",
          "Prefer":        "return=minimal",
        },
        body: JSON.stringify({ plan: "free" }),
      }
    );
    if (!res.ok) { setStatus("⚠ تعذّر الإلغاء. حاول مجدداً.", "error"); return; }
  } catch (e) { setStatus("⚠ خطأ في الشبكة.", "error"); return; }
  await api.storage.local.set({ user_plan: "free" });
  document.getElementById("cancel-sub").style.display = "none";
  document.getElementById("upgrade").style.display    = "block";
  setStatus("تم إلغاء الاشتراك.", "error");
});

// -------- REPORT --------

document.getElementById("report-lesson").addEventListener("click", async () => {
  const { sb_user_email, sb_user_id } = await getSession();
  if (!sb_user_email) return;
  const url = `${REPORT_URL}?email=${encodeURIComponent(sb_user_email)}&user_id=${encodeURIComponent(sb_user_id || "")}`;
  await openTab(url);
});

// -------- INIT --------

(async () => {
  const stored = await getSession();

  if (!stored.sb_access_token) {
    await clearPendingAuth();
    showScreen("auth-screen");
    return;
  }

  if (stored.sb_access_token === "email_verified" && stored.sb_user_email) {
    await loadAppScreen(SUPABASE_ANON_KEY, stored.sb_user_email);
    return;
  }

  // Validate stored Supabase token
  const { ok, data } = await getUser(stored.sb_access_token);

  if (!ok || !data?.email) {
    await clearSession();
    showScreen("auth-screen");
    return;
  }

  await loadAppScreen(stored.sb_access_token, data.email);
})();
