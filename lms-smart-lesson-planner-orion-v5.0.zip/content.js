// ===============================
// LMS Smart Lesson Planner
// Content Script — v4.0
//
// Architecture: direct fetch from content script.
// No background messaging. Works on Firefox, Chrome, and Orion.
// ===============================

// ===============================
// BROWSER API SHIM
// Firefox exposes `browser` with native Promises.
// Chrome/Orion exposes `chrome` with callbacks — we wrap what we use.
// ===============================

const api = (() => {
  if (typeof browser !== "undefined" && browser.runtime) {
    return browser;
  }
  return {
    runtime: chrome.runtime,
    tabs: chrome.tabs,
    storage: {
      local: {
        get:  (keys)  => new Promise((resolve) => chrome.storage.local.get(keys, resolve)),
        set:  (items) => new Promise((resolve) => chrome.storage.local.set(items, resolve)),
      },
    },
  };
})();

// ===============================
// CONFIG
// ANON_KEY is the Supabase public anon key — intentionally in source.
// It is safe to expose; access is gated server-side by RLS and
// authenticated Supabase session tokens.
// ===============================

const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6bmVneGtmd3d0cWt5dGtvbGpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIyNTI3ODgsImV4cCI6MjA4NzgyODc4OH0.bc7hSJF9DUmoNG0k54vWge_tQ4fgGWLi_xEn8YXX5ug";
const SUPABASE_URL = "https://rznegxkfwwtqkytkoljs.supabase.co";
const GENERATE_URL = "https://rznegxkfwwtqkytkoljs.supabase.co/functions/v1/generate-lesson";

console.log("LMS Smart Lesson Planner v4.0 — content script loaded.");

// ===============================
// STATE
// ===============================

let lastLesson      = null;   // last title seen by the poll loop
let dismissedLesson = null;   // title the teacher said "لا" to
let currentLesson   = null;   // { lessonTitle, grade, subject } — active request
let isGenerating    = false;
let panelState      = null;   // 'confirm' | 'loading' | 'success' | 'error' | 'info'
let loadingTimer    = null;
let watchdogTimer   = null;
let abortController = null;
let lmsPanel        = null;

async function refreshSupabaseSession(refreshToken) {
  if (!refreshToken) return null;
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST",
    headers: {
      "apikey": ANON_KEY,
      "Authorization": `Bearer ${ANON_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ refresh_token: refreshToken })
  });
  if (!res.ok) return null;
  const data = await res.json().catch(() => null);
  if (!data?.access_token || !data?.refresh_token || !data?.user?.email) return null;

  await api.storage.local.set({
    sb_access_token: data.access_token,
    sb_refresh_token: data.refresh_token,
    sb_user_email: data.user.email,
    sb_user_id: data.user.id || ""
  });

  return data;
}

async function getValidAccessToken() {
  const storage = await api.storage.local.get(["sb_user_email", "sb_access_token", "sb_refresh_token"]);
  if (!storage.sb_user_email) return null;
  if (!storage.sb_access_token) return null;
  if (storage.sb_access_token === "email_verified") {
    return {
      mode: "email_verified",
      accessToken: null,
      userEmail: storage.sb_user_email
    };
  }

  const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: {
      "apikey": ANON_KEY,
      "Authorization": `Bearer ${storage.sb_access_token}`
    }
  });
  if (userRes.ok) {
    return {
      mode: "session",
      accessToken: storage.sb_access_token,
      userEmail: storage.sb_user_email
    };
  }

  const refreshed = await refreshSupabaseSession(storage.sb_refresh_token);
  if (!refreshed?.access_token) return null;
  return {
    mode: "session",
    accessToken: refreshed.access_token,
    userEmail: refreshed.user?.email || storage.sb_user_email
  };
}

// ===============================
// RE-TRIGGER: clicking same lesson after "لا" resets dismiss
// ===============================

document.addEventListener("click", (e) => {
  const node = e.target.closest(".jstree-anchor");
  if (!node) return;
  const title = document.querySelector("#PreparationTitle")?.value?.trim();
  if (title && title === dismissedLesson) {
    dismissedLesson = null;
    lastLesson = null;
  }
});

// ===============================
// GRADE / SUBJECT EXTRACTION
// ===============================

function extractGradeSubject() {
  const headerEl = [...document.querySelectorAll("div, span, h1, h2")]
    .find(el => el.innerText?.includes("عرض الشجرة") && el.innerText?.includes("صف"));
  if (!headerEl) return null;

  const headerText   = headerEl.innerText.trim();
  const subjectMatch = headerText.match(/-\s*(.*?)\s*صف/);
  const subject      = subjectMatch ? subjectMatch[1].trim() : null;
  const gradeMatch   = headerText.match(/صف\s+([ء-ي]+\s?[ء-ي]*)/);
  const gradePhrase  = gradeMatch ? gradeMatch[1].trim() : null;

  const arabicNumbers = {
    "أول": 1,  "ثاني": 2,  "ثالث": 3,  "رابع": 4,
    "خامس": 5, "سادس": 6,  "سابع": 7,  "ثامن": 8,
    "تاسع": 9, "عاشر": 10, "حادي عشر": 11,
    "الحادي عشر": 11, "ثاني عشر": 12, "الثاني عشر": 12
  };

  const gradeNumber = arabicNumbers[gradePhrase] || null;
  if (!gradeNumber || !subject) return null;
  return { grade: gradeNumber, subject };
}

// ===============================
// LESSON DETECTION — poll #PreparationTitle every 300ms
// The LMS sets this field whenever a درس is selected (not وحدة/فصل/كتاب).
// ===============================

setInterval(() => {
  const titleInput = document.querySelector("#PreparationTitle");
  if (!titleInput) return;

  const title = titleInput.value.trim();
  if (!title || title === lastLesson) return;

  lastLesson = title;
  console.log("Lesson detected:", title);

  const gs = extractGradeSubject();
  if (!gs) {
    showPanel("error", "⚠ تعذّر تحديد الصف أو المادة. أعد تحميل الصفحة.");
    return;
  }

  api.storage.local.get(["sb_user_email"]).then((storage) => {
    if (!storage.sb_user_email) {
      showPanel("error", "افتح نافذة الإضافة وسجّل بريدك الإلكتروني أولاً.");
      return;
    }
    if (isGenerating) {
      showPanel("loading", `⏳ جاري إنشاء تحضير: ${currentLesson?.lessonTitle || ""}`);
      return;
    }
    showConfirm(title, gs.grade, gs.subject);
  });

}, 300);

// ===============================
// MAIN GENERATION — direct fetch, no background required
// ===============================

async function generateLessonPlan(lessonTitle, grade, subject) {

  if (isGenerating) {
    showPanel("error", "⚠ جاري إنشاء تحضير، يرجى الانتظار حتى يكتمل.");
    return;
  }

  // Math subjects are handled by the dedicated LMS Math extension
  if (subject && subject.includes("رياضيات")) {
    showPanel("info",
      "➕ مادة الرياضيات متاحة في إضافة مخصصة توفر عرضاً أفضل للمعادلات والرموز الرياضية.\n\nثبّت إضافة: LMS Math Lesson Planner"
    );
    return;
  }

  isGenerating    = true;
  abortController = new AbortController();
  currentLesson   = { lessonTitle, grade, subject };

  startLoadingTimer(lessonTitle);

  // Watchdog: auto-retry after 35 s if no response
  let watchdogSeconds = 0;
  watchdogTimer = setInterval(() => {
    watchdogSeconds++;
    if (watchdogSeconds >= 35) {
      stopLoadingTimer();
      isGenerating = false;
      const retry = currentLesson;
      if (retry) {
        console.log("Watchdog: auto-retrying...");
        generateLessonPlan(retry.lessonTitle, retry.grade, retry.subject);
      }
    }
  }, 1000);

  try {

    const auth = await getValidAccessToken();
    if (!auth?.userEmail) {
      stopLoadingTimer();
      showPanel("error", "افتح نافذة الإضافة وسجّل بريدك الإلكتروني أولاً.");
      isGenerating = false;
      return;
    }

    const response = await fetch(GENERATE_URL, {
      method: "POST",
      signal: abortController.signal,
      headers: {
        "Content-Type":       "application/json",
        "apikey":             ANON_KEY,
        // Keep Authorization compatible with edge gateway validation.
        // The real authenticated user token is sent in x-supabase-auth.
        "Authorization":      `Bearer ${ANON_KEY}`,
        ...(auth.accessToken ? { "x-supabase-auth": auth.accessToken } : {}),
        ...(auth.userEmail ? { "x-user-email": auth.userEmail } : {})
      },
      body: JSON.stringify({
        grade:              grade,
        subject:            subject,
        lessonTitle:        lessonTitle
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || `Server error ${response.status}.`);
    }

    const responseData = await response.json();
    if (responseData.error) throw new Error(responseData.error);

    stopLoadingTimer();

    // Discard if teacher cancelled while waiting
    if (!currentLesson) return;

    distributeSections(responseData.result || "", subject);
    showPanel("success", "✅ تم إنشاء التحضير بنجاح!");

  } catch (error) {

    if (error.name === "AbortError") return; // user cancelled — already cleaned up
    console.error("Generation error:", error);
    stopLoadingTimer();
    showPanel("error", "⚠ " + (error?.message || "حدث خطأ."));

  } finally {
    isGenerating = false;
  }
}

// ===============================
// LOADING TIMER
// ===============================

function startLoadingTimer(title) {
  if (loadingTimer)  clearInterval(loadingTimer);
  if (watchdogTimer) clearInterval(watchdogTimer);
  panelState = "loading";
  let seconds = 0;
  showPanel("loading", `⏳ جاري إنشاء تحضير: ${title} 0s`);
  loadingTimer = setInterval(() => {
    if (panelState !== "loading") return;
    seconds++;
    showPanel("loading", `⏳ جاري إنشاء تحضير: ${title} ${seconds}s`);
  }, 1000);
}

function stopLoadingTimer() {
  if (loadingTimer)  { clearInterval(loadingTimer);  loadingTimer  = null; }
  if (watchdogTimer) { clearInterval(watchdogTimer); watchdogTimer = null; }
}

// ===============================
// FLOATING PANEL
// ===============================

function createPanel() {
  if (lmsPanel) return;

  lmsPanel = document.createElement("div");
  lmsPanel.id = "lms-floating-panel";

  const hdr   = document.createElement("div");
  hdr.className = "lms-header";

  const hspan = document.createElement("span");
  hspan.textContent = "LMS Smart Lesson Planner";

  const cbtn = document.createElement("button");
  cbtn.id = "lms-close";
  cbtn.textContent = "×";
  cbtn.style.display = "none";

  hdr.appendChild(hspan);
  hdr.appendChild(cbtn);

  const body = document.createElement("div");
  body.id = "lms-body";

  lmsPanel.appendChild(hdr);
  lmsPanel.appendChild(body);
  document.body.appendChild(lmsPanel);
  makeDraggable(lmsPanel);

  // Close/cancel: abort fetch, reset all state
  cbtn.onclick = () => {
    if (abortController) { abortController.abort(); abortController = null; }
    isGenerating  = false;
    currentLesson = null;
    panelState    = null;
    lastLesson    = null;
    stopLoadingTimer();
    lmsPanel.remove();
    lmsPanel = null;
  };
}

function showConfirm(lessonTitle, grade, subject) {
  createPanel();
  panelState = "confirm";

  const cbtn = document.getElementById("lms-close");
  if (cbtn) cbtn.style.display = "none";

  const body = document.getElementById("lms-body");
  body.innerHTML = "";
  body.className = "lms-body-confirm";

  const question = document.createElement("p");
  question.className = "lms-confirm-question";
  question.textContent = "هل تريد إنشاء تحضير لهذا الدرس؟";

  const titleEl = document.createElement("p");
  titleEl.className = "lms-confirm-title";
  titleEl.textContent = lessonTitle;

  const btnRow = document.createElement("div");
  btnRow.className = "lms-btn-row";

  const yesBtn = document.createElement("button");
  yesBtn.className = "lms-btn lms-btn-yes";
  yesBtn.textContent = "نعم، أنشئ التحضير";
  yesBtn.onclick = () => { generateLessonPlan(lessonTitle, grade, subject); };

  const noBtn = document.createElement("button");
  noBtn.className = "lms-btn lms-btn-no";
  noBtn.textContent = "لا";
  noBtn.onclick = () => {
    dismissedLesson = lessonTitle;
    lmsPanel.remove();
    lmsPanel = null;
  };

  btnRow.appendChild(yesBtn);
  btnRow.appendChild(noBtn);
  body.appendChild(question);
  body.appendChild(titleEl);
  body.appendChild(btnRow);
}

function showPanel(type, message) {
  createPanel();
  panelState = type;

  const cbtn = document.getElementById("lms-close");
  if (cbtn) cbtn.style.display =
    (type === "success" || type === "error" || type === "info") ? "block" : "none";

  const body = document.getElementById("lms-body");
  body.innerHTML = "";
  body.className = "";

  const statusDiv = document.createElement("div");
  statusDiv.className = "lms-status " + type;
  statusDiv.textContent = message;
  body.appendChild(statusDiv);

  if (type === "loading") {
    const cancelBtn = document.createElement("button");
    cancelBtn.className = "lms-btn lms-btn-cancel-gen";
    cancelBtn.textContent = "إلغاء التحضير";
    cancelBtn.onclick = () => {
      if (abortController) { abortController.abort(); abortController = null; }
      isGenerating  = false;
      currentLesson = null;
      panelState    = null;
      lastLesson    = null;
      stopLoadingTimer();
      lmsPanel.remove();
      lmsPanel = null;
    };
    body.appendChild(cancelBtn);
  }
}

function makeDraggable(el) {
  let isDragging = false, offsetX = 0, offsetY = 0;
  const header = el.querySelector(".lms-header");
  header.addEventListener("mousedown", (e) => {
    isDragging = true;
    const rect = el.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    document.body.style.userSelect = "none";
  });
  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    el.style.left  = (e.clientX - offsetX) + "px";
    el.style.top   = (e.clientY - offsetY) + "px";
    el.style.right = "auto";
  });
  document.addEventListener("mouseup", () => {
    isDragging = false;
    document.body.style.userSelect = "";
  });
}

// ===============================
// STYLES
// ===============================

const style = document.createElement("style");
style.textContent = `
#lms-floating-panel {
  position: fixed;
  top: 100px;
  right: 40px;
  width: 280px;
  background: white;
  border-radius: 18px;
  box-shadow: 0 15px 35px rgba(0,0,0,0.2);
  z-index: 999999;
  font-family: "Noto Kufi Arabic", Roboto, "open sans", sans-serif;
  overflow: hidden;
}
.lms-header {
  position: relative;
  background: #1e40af;
  color: white;
  padding: 12px 40px;
  font-size: 13px;
  font-weight: 600;
  text-align: center;
  cursor: move;
}
#lms-close {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  background: transparent;
  border: none;
  color: white;
  font-size: 16px;
  cursor: pointer;
}
.lms-status {
  padding: 16px 18px;
  font-size: 14px;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  gap: 6px;
  direction: rtl;
}
.lms-status.loading { background: #fff7ed; color: #1e40af; }
.lms-status.success { background: #ecfdf5; color: #065f46; }
.lms-status.error   { background: #fef2f2; color: #7f1d1d; }
.lms-status.info    { background: #eff6ff; color: #1e3a8a; white-space: pre-line; }
.lms-body-confirm {
  background: #f8faff;
  direction: rtl;
  text-align: center;
  padding: 16px 14px 18px;
}
.lms-confirm-question {
  color: #1e3a8a;
  font-size: 13px;
  font-weight: 700;
  margin: 0 0 8px 0;
}
.lms-confirm-title {
  color: #374151;
  font-size: 12px;
  font-weight: 600;
  background: #e0e7ff;
  border-radius: 8px;
  padding: 6px 10px;
  margin: 0 0 14px 0;
}
.lms-btn-row {
  display: flex;
  gap: 10px;
  justify-content: center;
}
.lms-btn {
  border: none;
  border-radius: 10px;
  font-size: 13px;
  font-weight: 700;
  padding: 9px 14px;
  cursor: pointer;
  transition: opacity 0.15s;
  font-family: "Noto Kufi Arabic", Roboto, "open sans", sans-serif;
}
.lms-btn:active { opacity: 0.8; }
.lms-btn-yes { background: #1e40af; color: white; }
.lms-btn-no  { background: #f3f4f6; color: #374151; border: 1.5px solid #d1d5db; }
.lms-btn-cancel-gen {
  display: block;
  width: calc(100% - 36px);
  margin: 0 18px 14px;
  background: #f9fafb;
  color: #6b7280;
  border: 1.5px solid #e5e7eb;
  border-radius: 10px;
  font-size: 13px;
  font-weight: 700;
  padding: 8px;
  cursor: pointer;
  font-family: "Noto Kufi Arabic", Roboto, "open sans", sans-serif;
  transition: opacity 0.15s;
}
.lms-btn-cancel-gen:active { opacity: 0.8; }
.lms-sub {
  color: #991b1b;
  font-weight: bold;
  font-size: 17px;
  display: block;
  margin: 6px 0 2px;
}
`;
document.head.appendChild(style);

// ===============================
// SECTION EXTRACTOR
// Uses simple substring search — faster and more reliable than regex
// for the fixed header strings the AI always produces.
// ===============================

function isEnglishContent(text) {
  return /Key Vocabulary\s*:/i.test(text) ||
         /Warm-up\s*[\/:]/.test(text) ||
         /Lesson Procedures\s*:/i.test(text);
}

function getSection(text, start, end) {
  const startIndex = text.indexOf(start);
  if (startIndex === -1) return "";
  const from     = startIndex + start.length;
  let endIndex   = end ? text.indexOf(end, from) : -1;
  if (endIndex === -1) endIndex = text.length;
  return text.substring(from, endIndex).trim();
}

// ===============================
// DISTRIBUTE AI SECTIONS INTO EDITORS
// ===============================

function distributeSections(fullText, subject) {
  console.log("FULL AI TEXT:", fullText);

  const english  = isEnglishContent(fullText);
  const sections = english ? {
    vocabulary:  getSection(fullText, "Key Vocabulary:",                          "Warm-up"),
    preLearning: getSection(fullText, "Warm-up / Prior Knowledge:",               "Lesson Procedures"),
    activities:  getSection(fullText, "Lesson Procedures / Teaching Activities:", "Formative Assessment"),
    formative:   getSection(fullText, "Formative Assessment:",                    "Summative Assessment"),
    summative:   getSection(fullText, "Summative Assessment:",                    "Notes"),
    notes:       getSection(fullText, "Notes:",                                   null)
  } : {
    vocabulary:  getSection(fullText, "المفاهيم:",                               "التهيئة"),
    preLearning: getSection(fullText, "التهيئة / التمهيد / التعلم القبلي",       "إجراءات سير الدرس"),
    activities:  getSection(fullText, "إجراءات سير الدرس / الأنشطة التدريسية",  "التقويم التكويني"),
    formative:   getSection(fullText, "التقويم التكويني",                        "التقويم الختامي"),
    summative:   getSection(fullText, "التقويم الختامي",                         "ملاحظات"),
    notes:       getSection(fullText, "ملاحظات:",                                null)
  };

  console.log("SECTIONS:", sections);

  const contents = [
    sections.vocabulary, sections.preLearning, sections.activities,
    sections.formative,  sections.summative,   sections.notes
  ];

  let attempts = 0;
  function tryInsert() {
    const editors = Array.from(document.querySelectorAll("iframe.cke_wysiwyg_frame"))
      .filter(iframe => iframe.contentDocument && iframe.contentDocument.body);

    if (editors.length < 6) {
      attempts++;
      if (attempts < 20) { setTimeout(tryInsert, 500); return; }
      console.warn("CKEditor frames did not appear after max attempts.");
      return;
    }

    editors.forEach((iframe, i) => {
      if (!contents[i]) return;
      const doc = iframe.contentDocument || iframe.contentWindow.document;
      if (!doc || !doc.body) return;

      // Inject math styles into editor iframe if not already present
      if (!doc.getElementById("lms-math-styles")) {
        const styleEl = doc.createElement("style");
        styleEl.id = "lms-math-styles";
        styleEl.textContent = MATH_STYLES;
        (doc.head || doc.documentElement).appendChild(styleEl);
      }

      // Clean bare LaTeX symbols that may appear outside $$ markers
      let text = contents[i]
        .replace(/###/g, "")
        .replace(/\*\*/g, "")
        .replace(/\\times/g, "×")
        .replace(/\\cdot/g,  "·")
        .replace(/\\div/g,   "÷")
        .replace(/\\pm/g,    "±");

      // Render math expressions, then apply section heading formatting
      const isMath = subject && subject.includes("رياضيات");
      let processed = renderMath(text, isMath);
      processed = applyFormatting(processed, isMath);

      const html = english
        ? `<div style="direction:ltr;text-align:left;">${processed}</div>`
        : `<div style="direction:rtl;text-align:right;font-family:'Noto Kufi Arabic',sans-serif;line-height:2;">${processed}</div>`;

      const parsed = new doc.defaultView.DOMParser()
        .parseFromString(`<body>${html}</body>`, "text/html");
      doc.body.replaceChildren(
        ...Array.from(parsed.body.childNodes).map(n => doc.adoptNode(n))
      );
      doc.body.dispatchEvent(new Event("input", { bubbles: true }));
    });

    console.log("All editors filled.");
  }

  tryInsert();
}

// ===============================
// MATH STYLES — injected into each CKEditor iframe
// ===============================

const MATH_STYLES = `
.lms-math {
  display: inline-block;
  font-family: "Noto Kufi Arabic", "Times New Roman", serif;
  font-size: 17px;
  color: #166534;
  font-weight: bold;
  direction: rtl;
  vertical-align: middle;
  margin: 0 4px;
}
.lms-frac {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  vertical-align: middle;
  margin: 0 3px;
  line-height: 1.15;
}
.lms-frac-num {
  border-bottom: 1.5px solid #166534;
  padding: 0 5px 1px;
  font-size: 0.9em;
  text-align: center;
}
.lms-frac-den {
  padding: 1px 5px 0;
  font-size: 0.9em;
  text-align: center;
}
.lms-sub {
  color: #991b1b;
  font-weight: bold;
  font-size: 17px;
  display: block;
  margin: 6px 0 2px;
}
.lms-math-block {
  display: block;
  font-family: "Noto Kufi Arabic", "Times New Roman", serif;
  font-size: 17px;
  color: #166534;
  font-weight: bold;
  direction: rtl;
  text-align: center;
  margin: 8px 0;
}
`;

// ===============================
// LATEX → HTML MATH RENDERER
// Pure CSS approach — no external dependencies.
// ===============================

function latexToHTML(latex) {
  let s = latex.trim();
  const tokens = [];

  function protect(html) {
    tokens.push(html);
    return `⟨${tokens.length - 1}⟩`;
  }

  function varSpan(t) {
    return `<span style="color:#166534;font-weight:bold;">${t}</span>`;
  }
  function fracHTML(n, d) {
    return `<span style="display:inline-flex;flex-direction:column;align-items:center;vertical-align:middle;margin:0 3px;font-size:0.88em;"><span style="border-bottom:1.5px solid currentColor;padding:0 4px;text-align:center;">${n}</span><span style="padding:0 4px;text-align:center;">${d}</span></span>`;
  }
  function binomHTML(n, k) {
    return `<span style="display:inline-flex;align-items:center;vertical-align:middle;margin:0 2px;"><span style="font-size:1.8em;line-height:1;font-weight:200;">(</span><span style="display:inline-flex;flex-direction:column;align-items:center;font-size:0.82em;margin:0 2px;"><span style="padding:1px 3px;text-align:center;">${n}</span><span style="padding:1px 3px;text-align:center;">${k}</span></span><span style="font-size:1.8em;line-height:1;font-weight:200;">)</span></span>`;
  }
  function supHTML(base, exp) {
    return `${base}<sup style="font-size:0.72em;vertical-align:super;line-height:0;">${exp}</sup>`;
  }
  function subHTML(base, sub) {
    return `${base}<sub style="font-size:0.72em;vertical-align:sub;line-height:0;">${sub}</sub>`;
  }
  function sqrtHTML(c) {
    return `<span style="border-top:1.5px solid currentColor;padding:1px 3px 0 2px;"><span style="font-size:1.05em;">√</span>${c}</span>`;
  }

  // \\text{} → protected span
  s = s.replace(/\\text\{([^}]*)\}/g, (_, t) => protect(varSpan(t)));

  // Structural (multi-pass for nesting)
  for (let pass = 0; pass < 5; pass++) {
    s = s.replace(/\\d?frac\{([^{}]*)\}\{([^{}]*)\}/g,
      (_, n, d) => protect(fracHTML(n, d)));
  }
  for (let pass = 0; pass < 5; pass++) {
    s = s.replace(/\\binom\{([^{}]*)\}\{([^{}]*)\}/g,
      (_, n, k) => protect(binomHTML(n, k)));
  }
  s = s.replace(/\\sqrt\{([^{}]*)\}/g, (_, c) => protect(sqrtHTML(c)));

  // Symbol substitutions
  const symbols = {
    "\\times": "×", "\\div": "÷", "\\cdot": "·", "\\pm": "±",
    "\\neq": "≠", "\\leq": "≤", "\\geq": "≥", "\\infty": "∞",
    "\\Rightarrow": " ⟹ ", "\\rightarrow": " → ",
    "\\iff": " ⟺ ", "\\Longleftrightarrow": " ⟺ ",
    "\\dots": "…", "\\ldots": "…", "\\sum": "Σ", "\\quad": "\u2003"
  };
  for (const [k, v] of Object.entries(symbols)) {
    s = s.split(k).join(v);
  }
  s = s.replace(/\\left[\(\[]/g, "").replace(/\\right[\)\]]/g, "");
  s = s.replace(/\\left|\\right/g, "");

  // sup/sub
  s = s.replace(/(⟨\d+⟩|\([^)]*\)|[٠-٩أ-يa-zA-Z]+)\^\{([^}]*)\}/g,
    (_, base, exp) => protect(supHTML(base, exp)));
  s = s.replace(/(⟨\d+⟩|\([^)]*\)|[٠-٩أ-يa-zA-Z]+)_\{([^}]*)\}/g,
    (_, base, sub) => protect(subHTML(base, sub)));

  // Remove remaining unknown commands and bare braces
  s = s.replace(/\\[a-zA-Z]+/g, "");
  s = s.replace(/[{}]/g, "");

  // Wrap Eastern Arabic numerals in serif span
  s = s.replace(/(?<![⟩\d])([٠-٩]+(?:[.,][٠-٩]+)?)(?![⟨\d])/g,
    (_, n) => protect(`<span style="font-family:'Times New Roman',serif;">${n}</span>`));

  // Operator spacing
  s = s.replace(/\s*([=+])\s*/g, " $1 ");

  // Resolve token placeholders (loop for nesting)
  let prev = "";
  while (prev !== s) {
    prev = s;
    s = s.replace(/⟨(\d+)⟩/g, (_, i) => tokens[parseInt(i)]);
  }

  return `<span style="font-family:'Times New Roman',serif;color:#166534;font-weight:bold;direction:ltr;unicode-bidi:embed;display:inline;">${s}</span>`;
}

function renderMath(text, isMath) {
  if (!isMath) {
    // Non-math subjects: strip $$ markers and clean LaTeX
    return text.replace(/\$\$([^$]+)\$\$/g, (_, expr) =>
      expr.trim()
        .replace(/\\text\{([^}]*)\}/g, "$1")
        .replace(/\\[a-zA-Z]+/g, "")
        .replace(/[{}]/g, "")
    );
  }
  // Math subjects: convert each $$ block to styled HTML
  return text.replace(/\$\$([^$]+)\$\$/g, (_, expr) => latexToHTML(expr));
}

// ===============================
// TEXT FORMATTER
// Applies section headings, sub-headings, digit conversion, newlines.
// ===============================

function applyFormatting(text, isMath = false) {

  // Western → Eastern Arabic digits (math subjects only)
  if (isMath) {
    text = text.replace(/[0-9]/g, d => "٠١٢٣٤٥٦٧٨٩"[d]);

    // Unicode superscripts → Eastern Arabic superscripts
    const supMap = {"⁰":"٠","¹":"١","²":"٢","³":"٣","⁴":"٤","⁵":"٥","⁶":"٦","⁷":"٧","⁸":"٨","⁹":"٩"};
    text = text.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]+/g, m =>
      `<sup>${m.split("").map(c => supMap[c] || c).join("")}</sup>`);
  }

  // Sub-headings (أولاً، ثانياً …) → red bold
  text = text.replace(
    /^((?:أولاً|ثانياً|ثالثاً|رابعاً|خامساً|سادساً|سابعاً|ثامناً|تاسعاً|عاشراً)[^\n]*)$/gm,
    '<span class="lms-sub">$1</span>'
  );

  // Section headers → bold
  const headers = [
    ["المفاهيم:",                                         "<strong>المفاهيم:</strong><br>"],
    ["التهيئة / التمهيد / التعلم القبلي:",                "<strong>التهيئة / التمهيد / التعلم القبلي:</strong><br>"],
    ["إجراءات سير الدرس / الأنشطة التدريسية:",            "<strong>إجراءات سير الدرس / الأنشطة التدريسية:</strong><br>"],
    ["التقويم التكويني:",                                 "<strong>التقويم التكويني:</strong><br>"],
    ["التقويم الختامي:",                                  "<strong>التقويم الختامي:</strong><br>"],
    ["ملاحظات:",                                          "<strong>ملاحظات:</strong><br>"],
    ["Key Vocabulary:",                                   "<strong>Key Vocabulary:</strong><br>"],
    ["Warm-up / Prior Knowledge:",                        "<strong>Warm-up / Prior Knowledge:</strong><br>"],
    ["Lesson Procedures / Teaching Activities:",          "<strong>Lesson Procedures / Teaching Activities:</strong><br>"],
    ["Formative Assessment:",                             "<strong>Formative Assessment:</strong><br>"],
    ["Summative Assessment:",                             "<strong>Summative Assessment:</strong><br>"],
    ["Notes:",                                            "<strong>Notes:</strong><br>"]
  ];
  for (const [from, to] of headers) {
    text = text.split(from).join(to);
  }

  // Newlines → <br>, collapse 3+ consecutive breaks to 2
  text = text.replace(/\n/g, "<br>").replace(/(<br>\s*){3,}/g, "<br><br>");

  return text;
}

