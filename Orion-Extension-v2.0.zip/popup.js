// -------- CONFIG --------

const api = typeof browser !== "undefined" ? browser : chrome;

const SUPABASE_URL = "https://rznegxkfwwtqkytkoljs.supabase.co";

const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6bmVneGtmd3d0cWt5dGtvbGpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIyNTI3ODgsImV4cCI6MjA4NzgyODc4OH0.bc7hSJF9DUmoNG0k54vWge_tQ4fgGWLi_xEn8YXX5ug";

const CHECKOUT_URL =
  "https://nooredu.lemonsqueezy.com/checkout/buy/a5d24d1b-709e-449e-87a8-94dc4bd03d83";

const REGISTER_FN = `${SUPABASE_URL}/functions/v1/register-user`;

// -------- HELPERS --------

function setStatus(msg, type) {
  const el = document.getElementById("status");
  el.textContent = msg;
  el.className = type;
}

// -------- RUN WHEN POPUP OPENS --------
// Check email in storage AND sync plan from Supabase

(async () => {

  const storage = await api.storage.local.get(["user_email", "user_id"]);
  const userEmail = storage.user_email;

  if (!userEmail) return;

  document.getElementById("email").value = userEmail;
  document.getElementById("email").disabled = true;

  // Sync plan from Supabase by email so upgrades reflect immediately
  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/users?email=eq.${encodeURIComponent(userEmail)}&select=user_id,plan`,
      {
        headers: {
          "apikey": SUPABASE_ANON_KEY,
          "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
        }
      }
    );
    const rows = await res.json();
    if (rows && rows.length > 0) {
      const row = rows[0];
      // Update local user_id AND email to match DB (fixes mismatch after upgrade)
      await api.storage.local.set({ user_id: row.user_id, user_plan: row.plan, user_email: userEmail });

      if (row.plan === "premium") {
        setStatus("✦ Premium plan active", "success");
      } else {
        setStatus("Free trial active", "success");
      }
    }
  } catch (e) {
    // Network error on sync — not critical
    console.warn("Plan sync failed:", e);
  }

})();


// -------- FREE TRIAL BUTTON --------

document.getElementById("trial").addEventListener("click", async () => {

  const emailInput = document.getElementById("email");
  const email = emailInput.value.trim();

  if (!email) {
    setStatus("Please enter an email.", "error");
    return;
  }

  let { user_id } = await api.storage.local.get(["user_id"]);
  if (!user_id) {
    user_id = crypto.randomUUID();
    await api.storage.local.set({ user_id });
  }

  let data;
  try {
    const response = await fetch(REGISTER_FN, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({ user_id, email })
    });
    data = await response.json();
  } catch (err) {
    setStatus("⚠ Network error. Check your connection.", "error");
    return;
  }

  if (data.error) {
    setStatus(data.error, "error");
    return;
  }

  // Store email AND the per-user access token returned by the server
  await api.storage.local.set({
    user_email: email,
    access_token: data.access_token
  });
  emailInput.disabled = true;
  setStatus("✦ Free trial activated!", "success");

});


// -------- UPGRADE BUTTON --------

document.getElementById("upgrade").addEventListener("click", async () => {

  const { user_email } = await api.storage.local.get(["user_email"]);

  if (!user_email) {
    setStatus("Please activate the trial first.", "error");
    return;
  }

  // Use URLSearchParams so brackets are properly encoded → checkout%5Bemail%5D=...
  // Without this, iOS browsers send raw brackets and LemonSqueezy returns 422
  const params = new URLSearchParams();
  params.set("checkout[email]", user_email);
  const checkoutUrl = CHECKOUT_URL + "?" + params.toString();

  // api.tabs.create is unreliable on Orion iOS — window.open is the safe fallback
  try {
    await api.tabs.create({ url: checkoutUrl });
  } catch (e) {
    window.open(checkoutUrl, "_blank");
  }

});
