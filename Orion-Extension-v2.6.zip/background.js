// ===============================
// LMS Smart Planning Tool
// Background Script — Orion iOS build (MV2)
// Minimal — all logic runs in content.js on iOS
// ===============================

console.log("BACKGROUND SCRIPT STARTED (Orion iOS build)");

browser.runtime.onInstalled.addListener(() => {
  console.log("Extension installed.");
});
