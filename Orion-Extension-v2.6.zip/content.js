// ===============================
// LMS Smart Lesson Planner
// Content Script — Orion iOS build v2.5
// Direct fetch, no background script required
// ===============================

const api = typeof browser !== "undefined" ? browser : chrome;

console.log("CONTENT SCRIPT LOADED (Orion iOS build)");

const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6bmVneGtmd3d0cWt5dGtvbGpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIyNTI3ODgsImV4cCI6MjA4NzgyODc4OH0.bc7hSJF9DUmoNG0k54vWge_tQ4fgGWLi_xEn8YXX5ug";

let lastLesson      = null;
let dismissedLesson = null; // lesson the teacher said لا to
let currentLesson   = null; // { lessonTitle, grade, subject } — kept for auto-retry
let loadingTimer    = null;
let watchdogTimer   = null;
let isGenerating    = false;
let lmsPanel        = null;

// Re-trigger confirmation when teacher clicks same درس after saying لا
document.addEventListener("click", (e) => {
  const node = e.target.closest(".jstree-anchor");
  if (!node) return;
  const title = document.querySelector("#PreparationTitle")?.value?.trim();
  if (title && title === dismissedLesson) {
    dismissedLesson = null;
    lastLesson = null;
  }
});

// ===============================
// GRADE / SUBJECT EXTRACTION
// ===============================

function extractGradeSubject() {
  const headerEl = [...document.querySelectorAll("div, span, h1, h2")]
    .find(el => el.innerText?.includes("عرض الشجرة") && el.innerText?.includes("صف"));
  if (!headerEl) return null;

  const headerText   = headerEl.innerText.trim();
  const subjectMatch = headerText.match(/-\s*(.*?)\s*صف/);
  const subject      = subjectMatch ? subjectMatch[1].trim() : null;
  const gradeMatch   = headerText.match(/صف\s+([ء-ي]+\s?[ء-ي]*)/);
  const gradePhrase  = gradeMatch ? gradeMatch[1].trim() : null;

  const arabicNumbers = {
    "أول": 1, "ثاني": 2, "ثالث": 3, "رابع": 4,
    "خامس": 5, "سادس": 6, "سابع": 7, "ثامن": 8,
    "تاسع": 9, "عاشر": 10, "حادي عشر": 11,
    "الحادي عشر": 11, "ثاني عشر": 12, "الثاني عشر": 12
  };

  const gradeNumber = arabicNumbers[gradePhrase] || null;
  if (!gradeNumber || !subject) return null;
  return { grade: gradeNumber, subject };
}

// ===============================
// LESSON DETECTION — Poll #PreparationTitle
// The LMS sets this field directly whenever a درس is selected —
// never for وحدة/فصل/كتاب. Perfect platform-agnostic signal.
// ===============================

setInterval(() => {
  const titleInput = document.querySelector("#PreparationTitle");
  if (!titleInput) return;

  const title = titleInput.value.trim();
  if (!title || title === lastLesson) return;

  lastLesson = title;
  console.log("Lesson detected via #PreparationTitle:", title);

  const gs = extractGradeSubject();
  if (!gs) {
    showPanel("error", "⚠ تعذّر تحديد الصف أو المادة. أعد تحميل الصفحة.");
    return;
  }

  // Check registration before showing confirmation
  api.storage.local.get(["user_email"], (storage) => {
    if (!storage.user_email) {
      showPanel("error", "افتح نافذة الإضافة وسجّل بريدك الإلكتروني أولاً.");
      return;
    }
    showConfirm(title, gs.grade, gs.subject);
  });

}, 300);

// ===============================
// FLOATING PANEL
// ===============================

function createPanel() {
  if (lmsPanel) return;

  lmsPanel = document.createElement("div");
  lmsPanel.id = "lms-floating-panel";

  const hdr   = document.createElement("div");
  hdr.className = "lms-header";

  const hspan = document.createElement("span");
  hspan.textContent = "LMS Smart Lesson Planner";

  const cbtn = document.createElement("button");
  cbtn.id = "lms-close";
  cbtn.textContent = "×";
  cbtn.style.display = "none"; // hidden until success/error

  hdr.appendChild(hspan);
  hdr.appendChild(cbtn);

  const body = document.createElement("div");
  body.id = "lms-body";

  lmsPanel.appendChild(hdr);
  lmsPanel.appendChild(body);
  document.body.appendChild(lmsPanel);

  // Drag
  let isDragging = false, offsetX = 0, offsetY = 0;
  hdr.addEventListener("mousedown", (e) => {
    isDragging = true;
    const rect = lmsPanel.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    document.body.style.userSelect = "none";
  });
  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    lmsPanel.style.left  = (e.clientX - offsetX) + "px";
    lmsPanel.style.top   = (e.clientY - offsetY) + "px";
    lmsPanel.style.right = "auto";
  });
  document.addEventListener("mouseup", () => {
    isDragging = false;
    document.body.style.userSelect = "";
  });

  cbtn.onclick = () => { lmsPanel.remove(); lmsPanel = null; };
}

function showConfirm(lessonTitle, grade, subject) {
  createPanel();

  const cbtn = document.getElementById("lms-close");
  if (cbtn) cbtn.style.display = "none";

  const body = document.getElementById("lms-body");
  body.innerHTML = "";
  body.className = "lms-body-confirm";

  const question = document.createElement("p");
  question.className = "lms-confirm-question";
  question.textContent = "هل تريد إنشاء تحضير لهذا الدرس؟";

  const titleEl = document.createElement("p");
  titleEl.className = "lms-confirm-title";
  titleEl.textContent = lessonTitle;

  const btnRow = document.createElement("div");
  btnRow.className = "lms-btn-row";

  const yesBtn = document.createElement("button");
  yesBtn.className = "lms-btn lms-btn-yes";
  yesBtn.textContent = "نعم، أنشئ التحضير";
  yesBtn.onclick = () => { generateLessonPlan(lessonTitle, grade, subject); };

  const noBtn = document.createElement("button");
  noBtn.className = "lms-btn lms-btn-no";
  noBtn.textContent = "لا";
  noBtn.onclick = () => {
    dismissedLesson = lessonTitle;
    lmsPanel.remove();
    lmsPanel = null;
  };

  btnRow.appendChild(yesBtn);
  btnRow.appendChild(noBtn);
  body.appendChild(question);
  body.appendChild(titleEl);
  body.appendChild(btnRow);
}

function showPanel(type, message) {
  createPanel();

  const cbtn = document.getElementById("lms-close");
  if (cbtn) cbtn.style.display = (type === "success" || type === "error") ? "block" : "none";

  const body = document.getElementById("lms-body");
  body.innerHTML = "";
  body.className = "";

  const statusDiv = document.createElement("div");
  statusDiv.className = "lms-status " + type;
  statusDiv.textContent = message;
  body.appendChild(statusDiv);
}

function updatePanel(type, message) { showPanel(type, message); }

function startLoadingTimer(title) {
  if (loadingTimer) clearInterval(loadingTimer);
  let seconds = 0;
  showPanel("loading", `⏳ جاري إنشاء تحضير: ${title} 0s`);
  loadingTimer = setInterval(() => {
    seconds++;
    showPanel("loading", `⏳ جاري إنشاء تحضير: ${title} ${seconds}s`);
  }, 1000);
}

function stopLoadingTimer() {
  if (loadingTimer)  { clearInterval(loadingTimer);  loadingTimer  = null; }
  if (watchdogTimer) { clearInterval(watchdogTimer); watchdogTimer = null; }
}

// ===============================
// MAIN GENERATION — direct fetch
// ===============================

async function generateLessonPlan(lessonTitle, grade, subject) {

  if (isGenerating) return;
  isGenerating = true;

  currentLesson = { lessonTitle, grade, subject };

  if (!lessonTitle || !grade || !subject) {
    showPanel("error", "⚠ بيانات الدرس غير مكتملة.");
    isGenerating = false;
    return;
  }

  const storage = await api.storage.local.get(["user_email", "user_id"]);
  let userEmail = storage.user_email;
  let userId    = storage.user_id;

  if (!userId) {
    userId = crypto.randomUUID();
    await api.storage.local.set({ user_id: userId });
  }

  const deviceFingerprint = await getDeviceFingerprint();

  if (!userEmail) {
    showPanel("error", "افتح نافذة الإضافة وسجّل بريدك الإلكتروني أولاً.");
    isGenerating = false;
    return;
  }

  startLoadingTimer(lessonTitle);

  // Watchdog: auto-retry after 35s
  let watchdogSeconds = 0;
  watchdogTimer = setInterval(() => {
    watchdogSeconds++;
    if (watchdogSeconds >= 35) {
      stopLoadingTimer();
      isGenerating = false;
      if (currentLesson) {
        console.log("Watchdog: auto-retrying...");
        generateLessonPlan(currentLesson.lessonTitle, currentLesson.grade, currentLesson.subject);
      }
    }
  }, 1000);

  try {

    const response = await fetch(
      "https://rznegxkfwwtqkytkoljs.supabase.co/functions/v1/generate-lesson",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": ANON_KEY,
          "Authorization": `Bearer ${ANON_KEY}`,
          "x-extension-secret": "303acfbd-ceaf-4f8f-b458-8a043661db92-96557a86-278a-4568-8e51-05ebb0d52a81"
        },
        body: JSON.stringify({
          user_id:            userId,
          email:              userEmail,
          grade:              grade,
          subject:            subject,
          lessonTitle:        lessonTitle,
          extension_secret:   "303acfbd-ceaf-4f8f-b458-8a043661db92-96557a86-278a-4568-8e51-05ebb0d52a81",
          device_fingerprint: deviceFingerprint
        })
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || "Server error.");
    }

    const responseData = await response.json();
    if (responseData.error) throw new Error(responseData.error);

    stopLoadingTimer();
    distributeSections(responseData.result || "");
    showPanel("success", "✅ تم إنشاء التحضير بنجاح!");

  } catch (error) {
    console.error("Generation error:", error);
    stopLoadingTimer();
    showPanel("error", "⚠ " + (error?.message || "حدث خطأ."));
  } finally {
    isGenerating = false;
  }

}

// ===============================
// DEVICE FINGERPRINTING
// ===============================

async function getDeviceFingerprint() {
  return Promise.race([
    _generateFingerprint(),
    new Promise(resolve => setTimeout(() => resolve("no-fingerprint-timeout"), 3000))
  ]);
}

async function _generateFingerprint() {
  const components = [];
  components.push(navigator.userAgent);
  components.push(`${screen.width}x${screen.height}x${screen.colorDepth}`);
  components.push(Intl.DateTimeFormat().resolvedOptions().timeZone);
  components.push(navigator.language);
  components.push(navigator.platform || "unknown");
  components.push(String(navigator.hardwareConcurrency || 0));

  try {
    const canvas = document.createElement("canvas");
    canvas.width = 200; canvas.height = 50;
    const ctx = canvas.getContext("2d");
    ctx.textBaseline = "top"; ctx.font = "14px Arial";
    ctx.fillStyle = "#f60"; ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = "#069"; ctx.fillText("LMS🎓fingerprint", 2, 15);
    ctx.fillStyle = "rgba(102,204,0,0.7)"; ctx.fillText("LMS🎓fingerprint", 4, 17);
    components.push(canvas.toDataURL());
  } catch(e) { components.push("no-canvas"); }

  try {
    const audioCtx   = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const analyser   = audioCtx.createAnalyser();
    const gain       = audioCtx.createGain();
    gain.gain.value  = 0;
    oscillator.connect(analyser); analyser.connect(gain); gain.connect(audioCtx.destination);
    oscillator.start(0);
    const buffer = new Float32Array(analyser.frequencyBinCount);
    analyser.getFloatFrequencyData(buffer);
    oscillator.stop(); audioCtx.close();
    components.push(buffer.slice(0, 10).join(","));
  } catch(e) { components.push("no-audio"); }

  const raw        = components.join("|||");
  const hashBuffer = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
  return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, "0")).join("");
}

// ===============================
// SECTION EXTRACTOR
// ===============================

function isEnglishContent(text) {
  return /Key Vocabulary\s*:/i.test(text) || /Warm-up\s*[\/:]/.test(text) || /Lesson Procedures\s*:/i.test(text);
}

function getSection(text, start, end) {
  const startIndex = text.indexOf(start);
  if (startIndex === -1) return "";
  const from     = startIndex + start.length;
  let endIndex   = end ? text.indexOf(end, from) : -1;
  if (endIndex === -1) endIndex = text.length;
  return text.substring(from, endIndex).trim();
}

// ===============================
// DISTRIBUTE AI SECTIONS
// ===============================

function distributeSections(fullText) {
  console.log("FULL AI TEXT:", fullText);

  const english  = isEnglishContent(fullText);
  const sections = english ? {
    vocabulary:  getSection(fullText, "Key Vocabulary:",                         "Warm-up"),
    preLearning: getSection(fullText, "Warm-up / Prior Knowledge:",              "Lesson Procedures"),
    activities:  getSection(fullText, "Lesson Procedures / Teaching Activities:","Formative Assessment"),
    formative:   getSection(fullText, "Formative Assessment:",                   "Summative Assessment"),
    summative:   getSection(fullText, "Summative Assessment:",                   "Notes"),
    notes:       getSection(fullText, "Notes:",                                  null)
  } : {
    vocabulary:  getSection(fullText, "المفاهيم:",                               "التهيئة"),
    preLearning: getSection(fullText, "التهيئة / التمهيد / التعلم القبلي",       "إجراءات سير الدرس"),
    activities:  getSection(fullText, "إجراءات سير الدرس / الأنشطة التدريسية",  "التقويم التكويني"),
    formative:   getSection(fullText, "التقويم التكويني",                        "التقويم الختامي"),
    summative:   getSection(fullText, "التقويم الختامي",                         "ملاحظات"),
    notes:       getSection(fullText, "ملاحظات:",                                null)
  };

  console.log("SECTIONS:", sections);

  let attempts = 0;
  function tryInsert() {
    const editors = document.querySelectorAll("iframe.cke_wysiwyg_frame");
    if (editors.length < 6) {
      attempts++;
      if (attempts < 20) setTimeout(tryInsert, 500);
      else console.warn("Editors not ready after max attempts.");
      return;
    }

    const contents = [
      sections.vocabulary, sections.preLearning, sections.activities,
      sections.formative,  sections.summative,   sections.notes
    ];

    editors.forEach((iframe, i) => {
      if (!contents[i]) return;
      const doc = iframe.contentDocument || iframe.contentWindow.document;
      if (!doc || !doc.body) return;
      const html = contents[i].replace(/\n/g, "<br>");
      doc.body.innerHTML = english
        ? `<div style="direction:ltr;text-align:left;">${html}</div>`
        : html;
      doc.body.dispatchEvent(new Event("input", { bubbles: true }));
    });

    console.log("All editors filled.");
  }

  tryInsert();
}

// ===============================
// STYLES
// ===============================

const style = document.createElement("style");
style.textContent = `
#lms-floating-panel {
  position: fixed;
  top: 100px;
  left: calc(100vw - 300px);
  width: 280px;
  background: white;
  border-radius: 18px;
  box-shadow: 0 15px 35px rgba(0,0,0,0.2);
  z-index: 999999;
  font-family: "Noto Kufi Arabic", Roboto, "open sans", sans-serif;
  overflow: hidden;
}
.lms-header {
  background: #1e40af;
  color: white;
  padding: 12px 40px;
  font-size: 13px;
  font-weight: 600;
  text-align: center;
  position: relative;
  cursor: move;
}
#lms-close {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  background: transparent;
  border: none;
  color: white;
  font-size: 16px;
  cursor: pointer;
}
.lms-status {
  padding: 16px 18px;
  font-size: 14px;
  font-weight: 600;
  display: flex;
  justify-content: center;
  text-align: center;
  direction: rtl;
}
.lms-status.loading { background: #fff7ed; color: #1e40af; }
.lms-status.success { background: #ecfdf5; color: #065f46; }
.lms-status.error   { background: #fef2f2; color: #7f1d1d; }
.lms-body-confirm {
  background: #f8faff;
  direction: rtl;
  text-align: center;
  padding: 16px 14px 18px;
}
.lms-confirm-question {
  color: #1e3a8a;
  font-size: 13px;
  font-weight: 700;
  margin: 0 0 8px 0;
}
.lms-confirm-title {
  color: #374151;
  font-size: 12px;
  font-weight: 600;
  background: #e0e7ff;
  border-radius: 8px;
  padding: 6px 10px;
  margin: 0 0 14px 0;
}
.lms-btn-row {
  display: flex;
  gap: 10px;
  justify-content: center;
}
.lms-btn {
  border: none;
  border-radius: 10px;
  font-size: 13px;
  font-weight: 700;
  padding: 9px 14px;
  cursor: pointer;
  transition: opacity 0.15s;
  font-family: "Noto Kufi Arabic", Roboto, "open sans", sans-serif;
}
.lms-btn:active { opacity: 0.8; }
.lms-btn-yes { background: #1e40af; color: white; }
.lms-btn-no  { background: #f3f4f6; color: #374151; border: 1.5px solid #d1d5db; }
`;
document.head.appendChild(style);
