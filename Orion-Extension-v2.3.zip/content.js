// ===============================
// LMS Smart Planning Tool
// Content Script — Orion iOS build
// Direct fetch, no background script required
// ===============================

const api = typeof browser !== "undefined" ? browser : chrome;

console.log("CONTENT SCRIPT LOADED (Orion iOS build)");

const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6bmVneGtmd3d0cWt5dGtvbGpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIyNTI3ODgsImV4cCI6MjA4NzgyODc4OH0.bc7hSJF9DUmoNG0k54vWge_tQ4fgGWLi_xEn8YXX5ug";

let lastLesson = null;
let loadingTimer = null;
let isGenerating = false;
let lmsPanel = null;

// ===============================
// FLOATING PANEL
// ===============================

function createPanel() {

  if (lmsPanel) return;

  lmsPanel = document.createElement("div");
  lmsPanel.id = "lms-floating-panel";

  const _hdr = document.createElement("div");
  _hdr.className = "lms-header";
  const _hspan = document.createElement("span");
  _hspan.textContent = "LMS Smart Lesson Planner";
  const _cbtn = document.createElement("button");
  _cbtn.id = "lms-close";
  _cbtn.textContent = "×";
  _hdr.appendChild(_hspan);
  _hdr.appendChild(_cbtn);
  const _sdiv = document.createElement("div");
  _sdiv.id = "lms-status";
  _sdiv.className = "lms-status loading";
  _sdiv.textContent = "⏳ Generating lesson...";
  lmsPanel.appendChild(_hdr);
  lmsPanel.appendChild(_sdiv);

  document.body.appendChild(lmsPanel);

  // Drag
  const header = _hdr;
  let isDragging = false;
  let offsetX = 0;
  let offsetY = 0;

  header.addEventListener("mousedown", (e) => {
    isDragging = true;
    const rect = lmsPanel.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    document.body.style.userSelect = "none";
  });

  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    lmsPanel.style.left = (e.clientX - offsetX) + "px";
    lmsPanel.style.top = (e.clientY - offsetY) + "px";
    lmsPanel.style.right = "auto";
  });

  document.addEventListener("mouseup", () => {
    isDragging = false;
    document.body.style.userSelect = "";
  });

  document.getElementById("lms-close").onclick = () => {
    lmsPanel.remove();
    lmsPanel = null;
  };

}

function updatePanel(type, message) {
  if (!lmsPanel) createPanel();
  const status = document.getElementById("lms-status");
  status.className = "lms-status " + type;
  status.innerText = message;
}

function startLoadingTimer(title) {
  if (loadingTimer) clearInterval(loadingTimer);
  let seconds = 0;
  updatePanel("loading", `⏳ جاري إنشاء تحضير: ${title} 0s`);
  loadingTimer = setInterval(() => {
    seconds++;
    updatePanel("loading", `⏳ جاري إنشاء تحضير: ${title} ${seconds}s`);
  }, 1000);
}

function stopLoadingTimer() {
  if (loadingTimer) {
    clearInterval(loadingTimer);
    loadingTimer = null;
  }
}

// ===============================
// LESSON DETECTION
// ===============================

function detectLesson() {

  const selected = document.querySelector('.jstree-anchor.jstree-clicked');
  if (!selected) return;

  // Layer 1 — jstree structural check.
  // Branches (فصل/وحدة) that are already loaded have jstree-open/closed
  // and aria-expanded=true. Leaves (درس) have jstree-leaf and no aria-expanded.
  // Confirmed from real DOM data.
  const parentLi = selected.closest("li");
  const isBranch = parentLi && (
    parentLi.classList.contains("jstree-open") ||
    parentLi.classList.contains("jstree-closed") ||
    (parentLi.classList.contains("jstree-node") && !parentLi.classList.contains("jstree-leaf"))
  );
  const isExpandable = selected.getAttribute("aria-expanded") !== null;
  if (isBranch || isExpandable) return;

  const lessonTitle = selected.innerText.trim();
  if (!lessonTitle) return;

  // Layer 2 — Arabic branch label check.
  // Catches the iOS lazy-load edge case: on first tap a branch node
  // temporarily has jstree-leaf before its children finish loading.
  const isBranchLabel = /^(فصل|الفصل|وحدة|الوحدة|كتاب)/.test(lessonTitle);
  if (isBranchLabel) return;

  // Layer 3 — title format check.
  // From real DOM data, every درس title is one of:
  //   Arabic  : "X-Y"  e.g. "3-2"
  //   English : contains "LessonN" anywhere, e.g.:
  //               "Unit4: Let's Talk : Lesson12"
  //               "Unit4: Let's Talk : Graded reader Lesson1"
  //               "Learning Club2 : Lesson2"
  // وحدة titles ("Unit4: Let's Talk", "Learning Club2") have no "LessonN" → excluded.
  const isArabicLesson  = /^\d+-\d+/.test(lessonTitle);
  const isEnglishLesson = /Lesson\s*\d+/i.test(lessonTitle);
  if (!isArabicLesson && !isEnglishLesson) return;

  const cleanLesson = lessonTitle;
  if (cleanLesson === lastLesson) return;
  lastLesson = cleanLesson;

  console.log("Valid lesson detected:", cleanLesson);

  const headerEl = [...document.querySelectorAll("div, span, h1, h2")]
    .find(el => el.innerText?.includes("عرض الشجرة") && el.innerText?.includes("صف"));

  let subject = null;
  let gradeNumber = null;

  if (headerEl) {
    const headerText = headerEl.innerText.trim();
    const subjectMatch = headerText.match(/-\s*(.*?)\s*صف/);
    subject = subjectMatch ? subjectMatch[1].trim() : null;
    const gradeMatch = headerText.match(/صف\s+([ء-ي]+\s?[ء-ي]*)/);
    const gradePhrase = gradeMatch ? gradeMatch[1].trim() : null;
    const arabicNumbers = {
      "أول": 1, "ثاني": 2, "ثالث": 3, "رابع": 4,
      "خامس": 5, "سادس": 6, "سابع": 7, "ثامن": 8,
      "تاسع": 9, "عاشر": 10, "حادي عشر": 11,
      "الحادي عشر": 11, "ثاني عشر": 12, "الثاني عشر": 12
    };
    gradeNumber = arabicNumbers[gradePhrase] || null;
  }

  generateLessonPlan(cleanLesson, gradeNumber, subject);

}

// ===============================
// MAIN GENERATION — direct fetch
// ===============================

async function generateLessonPlan(lessonTitle, grade, subject) {

  if (isGenerating) return;
  isGenerating = true;

  if (!lessonTitle || !grade || !subject) {
    updatePanel("error", "❌ Missing lesson information.");
    isGenerating = false;
    return;
  }

  const storage = await api.storage.local.get(["user_email", "user_id"]);
  let userEmail = storage.user_email;
  let userId = storage.user_id;

  if (!userId) {
    userId = crypto.randomUUID();
    await api.storage.local.set({ user_id: userId });
  }

  // Get device fingerprint
  const deviceFingerprint = await getDeviceFingerprint();

  if (!userEmail) {
    updatePanel("error", "افتح نافذة الإضافة وسجّل بريدك الإلكتروني أولاً.");
    isGenerating = false;
    lastLesson = null;
    return;
  }

  startLoadingTimer(lessonTitle);

  try {

    const response = await fetch(
      "https://rznegxkfwwtqkytkoljs.supabase.co/functions/v1/generate-lesson",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": ANON_KEY,
          "Authorization": `Bearer ${ANON_KEY}`,
          "x-extension-secret": "303acfbd-ceaf-4f8f-b458-8a043661db92-96557a86-278a-4568-8e51-05ebb0d52a81"
        },
        body: JSON.stringify({
          user_id: userId,
          email: userEmail,
          grade: grade,
          subject: subject,
          lessonTitle: lessonTitle,
          extension_secret: "303acfbd-ceaf-4f8f-b458-8a043661db92-96557a86-278a-4568-8e51-05ebb0d52a81",
          device_fingerprint: deviceFingerprint
        })
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || "Server error.");
    }

    const responseData = await response.json();

    if (responseData.error) {
      throw new Error(responseData.error);
    }

    stopLoadingTimer();
    lastLesson = null;
    distributeSections(responseData.result || "");
    updatePanel("success", "✅ تم إنشاء التحضير بنجاح!");

  } catch (error) {
    console.error("Generation error:", error);
    stopLoadingTimer();
    lastLesson = null;
    updatePanel("error", "⚠ " + (error?.message || "Request failed."));
  } finally {
    isGenerating = false;
  }

}

// ===============================
// DEVICE FINGERPRINTING
// ===============================

async function getDeviceFingerprint() {
  // Wrap in timeout — AudioContext can hang indefinitely on iOS
  return Promise.race([
    _generateFingerprint(),
    new Promise(resolve => setTimeout(() => resolve("no-fingerprint-timeout"), 3000))
  ]);
}

async function _generateFingerprint() {

  const components = [];

  // 1. User agent
  components.push(navigator.userAgent);

  // 2. Screen
  components.push(`${screen.width}x${screen.height}x${screen.colorDepth}`);

  // 3. Timezone
  components.push(Intl.DateTimeFormat().resolvedOptions().timeZone);

  // 4. Language
  components.push(navigator.language);

  // 5. Platform
  components.push(navigator.platform || "unknown");

  // 6. Hardware concurrency (CPU cores)
  components.push(String(navigator.hardwareConcurrency || 0));

  // 7. Canvas fingerprint
  try {
    const canvas = document.createElement("canvas");
    canvas.width = 200;
    canvas.height = 50;
    const ctx = canvas.getContext("2d");
    ctx.textBaseline = "top";
    ctx.font = "14px Arial";
    ctx.fillStyle = "#f60";
    ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = "#069";
    ctx.fillText("LMS🎓fingerprint", 2, 15);
    ctx.fillStyle = "rgba(102,204,0,0.7)";
    ctx.fillText("LMS🎓fingerprint", 4, 17);
    components.push(canvas.toDataURL());
  } catch (e) {
    components.push("no-canvas");
  }

  // 8. Audio fingerprint
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const analyser = audioCtx.createAnalyser();
    const gain = audioCtx.createGain();
    gain.gain.value = 0;
    oscillator.connect(analyser);
    analyser.connect(gain);
    gain.connect(audioCtx.destination);
    oscillator.start(0);
    const buffer = new Float32Array(analyser.frequencyBinCount);
    analyser.getFloatFrequencyData(buffer);
    oscillator.stop();
    audioCtx.close();
    components.push(buffer.slice(0, 10).join(","));
  } catch (e) {
    components.push("no-audio");
  }

  // Hash all components together
  const raw = components.join("|||");
  const hashBuffer = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(raw)
  );
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const fingerprint = hashArray.map(b => b.toString(16).padStart(2, "0")).join("");

  return fingerprint;
}

// ===============================
// SMART LMS DETECTOR
// ===============================

let observerInitialized = false;

function initLessonObserver() {

  if (observerInitialized) return;

  const waitForTree = setInterval(() => {
    const treeContainer = document.querySelector(".jstree-container-ul");
    if (!treeContainer) return;

    clearInterval(waitForTree);
    observerInitialized = true;

    let debounceTimer;
    const observer = new MutationObserver(() => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => detectLesson(), 300);
    });

    observer.observe(treeContainer, { childList: true, subtree: true });
    console.log("MutationObserver initialized.");
  }, 500);

}

window.addEventListener("load", () => {
  initLessonObserver();
});

// ===============================
// CLICK DETECTION
// ===============================

document.body.addEventListener("click", (e) => {
  const node = e.target.closest(".jstree-anchor");
  if (!node) return;
  setTimeout(() => detectLesson(), 200);
});

// ===============================
// SECTION EXTRACTOR
// ===============================

function isEnglishContent(text) {
  return /Key Vocabulary\s*:/i.test(text) || /Warm-up\s*[\/:]/.test(text) || /Lesson Procedures\s*:/i.test(text);
}

function getSection(text, start, end) {
  const startIndex = text.indexOf(start);
  if (startIndex === -1) return "";
  const from = startIndex + start.length;
  let endIndex = end ? text.indexOf(end, from) : -1;
  if (endIndex === -1) endIndex = text.length;
  return text.substring(from, endIndex).trim();
}

// ===============================
// DISTRIBUTE AI SECTIONS
// ===============================

function distributeSections(fullText) {

  console.log("FULL AI TEXT:", fullText);

  const english = isEnglishContent(fullText);
  const sections = english ? {
    vocabulary:  getSection(fullText, "Key Vocabulary:", "Warm-up"),
    preLearning: getSection(fullText, "Warm-up / Prior Knowledge:", "Lesson Procedures"),
    activities:  getSection(fullText, "Lesson Procedures / Teaching Activities:", "Formative Assessment"),
    formative:   getSection(fullText, "Formative Assessment:", "Summative Assessment"),
    summative:   getSection(fullText, "Summative Assessment:", "Notes"),
    notes:       getSection(fullText, "Notes:", null)
  } : {
    vocabulary:  getSection(fullText, "المفاهيم:", "التهيئة"),
    preLearning: getSection(fullText, "التهيئة / التمهيد / التعلم القبلي", "إجراءات سير الدرس"),
    activities:  getSection(fullText, "إجراءات سير الدرس / الأنشطة التدريسية", "التقويم التكويني"),
    formative:   getSection(fullText, "التقويم التكويني", "التقويم الختامي"),
    summative:   getSection(fullText, "التقويم الختامي", "ملاحظات"),
    notes:       getSection(fullText, "ملاحظات:", null)
  };

  console.log("SECTIONS:", sections);

  let attempts = 0;

  function tryInsert() {
    const editors = document.querySelectorAll("iframe.cke_wysiwyg_frame");
    if (editors.length < 6) {
      attempts++;
      if (attempts < 20) setTimeout(tryInsert, 500);
      else console.warn("Editors not ready after max attempts.");
      return;
    }

    const contents = [
      sections.vocabulary, sections.preLearning, sections.activities,
      sections.formative,  sections.summative,   sections.notes
    ];

    editors.forEach((iframe, i) => {
      if (!contents[i]) return;
      const doc = iframe.contentDocument || iframe.contentWindow.document;
      if (!doc || !doc.body) return;
      const _html = contents[i].replace(/\n/g, "<br>");
      doc.body.innerHTML = english
        ? `<div style="direction:ltr;text-align:left;">${_html}</div>`
        : _html;
      doc.body.dispatchEvent(new Event("input", { bubbles: true }));
    });

    console.log("All editors filled.");
  }

  tryInsert();

}

// ===============================
// STYLES
// ===============================

const style = document.createElement("style");
style.textContent = `
#lms-floating-panel {
  position: fixed;
  top: 100px;
  left: calc(100vw - 300px);
  width: 260px;
  background: white;
  border-radius: 18px;
  box-shadow: 0 15px 35px rgba(0,0,0,0.2);
  z-index: 999999;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  overflow: hidden;
}
.lms-header {
  background: #1e40af;
  color: white;
  padding: 12px;
  font-size: 13px;
  font-weight: 600;
  text-align: center;
  position: relative;
  cursor: move;
}
#lms-close {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  background: transparent;
  border: none;
  color: white;
  font-size: 16px;
  cursor: pointer;
}
.lms-status {
  padding: 16px;
  font-size: 14px;
  font-weight: 600;
  display: flex;
  justify-content: center;
  text-align: center;
  direction: rtl;
}
.lms-status.loading { background: #fff7ed; color: #1e40af; }
.lms-status.success { background: #ecfdf5; color: #065f46; }
.lms-status.error   { background: #fef2f2; color: #7f1d1d; }
`;
document.head.appendChild(style);
