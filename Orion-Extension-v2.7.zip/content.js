// ===============================
// LMS Smart Lesson Planner
// Content Script — Orion iOS build v2.5
// Direct fetch, no background script required
// ===============================

const api = typeof browser !== "undefined" ? browser : chrome;

console.log("CONTENT SCRIPT LOADED (Orion iOS build)");

const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ6bmVneGtmd3d0cWt5dGtvbGpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzIyNTI3ODgsImV4cCI6MjA4NzgyODc4OH0.bc7hSJF9DUmoNG0k54vWge_tQ4fgGWLi_xEn8YXX5ug";

let lastLesson      = null;
let dismissedLesson = null; // lesson the teacher said لا to
let currentLesson   = null; // { lessonTitle, grade, subject } — kept for auto-retry
let loadingTimer    = null;
let watchdogTimer   = null;
let isGenerating    = false;
let lmsPanel        = null;

// Re-trigger confirmation when teacher clicks same درس after saying لا
document.addEventListener("click", (e) => {
  const node = e.target.closest(".jstree-anchor");
  if (!node) return;
  const title = document.querySelector("#PreparationTitle")?.value?.trim();
  if (title && title === dismissedLesson) {
    dismissedLesson = null;
    lastLesson = null;
  }
});

// ===============================
// GRADE / SUBJECT EXTRACTION
// ===============================

function extractGradeSubject() {
  const headerEl = [...document.querySelectorAll("div, span, h1, h2")]
    .find(el => el.innerText?.includes("عرض الشجرة") && el.innerText?.includes("صف"));
  if (!headerEl) return null;

  const headerText   = headerEl.innerText.trim();
  const subjectMatch = headerText.match(/-\s*(.*?)\s*صف/);
  const subject      = subjectMatch ? subjectMatch[1].trim() : null;
  const gradeMatch   = headerText.match(/صف\s+([ء-ي]+\s?[ء-ي]*)/);
  const gradePhrase  = gradeMatch ? gradeMatch[1].trim() : null;

  const arabicNumbers = {
    "أول": 1, "ثاني": 2, "ثالث": 3, "رابع": 4,
    "خامس": 5, "سادس": 6, "سابع": 7, "ثامن": 8,
    "تاسع": 9, "عاشر": 10, "حادي عشر": 11,
    "الحادي عشر": 11, "ثاني عشر": 12, "الثاني عشر": 12
  };

  const gradeNumber = arabicNumbers[gradePhrase] || null;
  if (!gradeNumber || !subject) return null;
  return { grade: gradeNumber, subject };
}

// ===============================
// LESSON DETECTION — Poll #PreparationTitle
// The LMS sets this field directly whenever a درس is selected —
// never for وحدة/فصل/كتاب. Perfect platform-agnostic signal.
// ===============================

setInterval(() => {
  const titleInput = document.querySelector("#PreparationTitle");
  if (!titleInput) return;

  const title = titleInput.value.trim();
  if (!title || title === lastLesson) return;

  lastLesson = title;
  console.log("Lesson detected via #PreparationTitle:", title);

  const gs = extractGradeSubject();
  if (!gs) {
    showPanel("error", "⚠ تعذّر تحديد الصف أو المادة. أعد تحميل الصفحة.");
    return;
  }

  // Check registration before showing confirmation
  api.storage.local.get(["user_email"], (storage) => {
    if (!storage.user_email) {
      showPanel("error", "افتح نافذة الإضافة وسجّل بريدك الإلكتروني أولاً.");
      return;
    }
    showConfirm(title, gs.grade, gs.subject);
  });

}, 300);

// ===============================
// FLOATING PANEL
// ===============================

function createPanel() {
  if (lmsPanel) return;

  lmsPanel = document.createElement("div");
  lmsPanel.id = "lms-floating-panel";

  const hdr   = document.createElement("div");
  hdr.className = "lms-header";

  const hspan = document.createElement("span");
  hspan.textContent = "LMS Smart Lesson Planner";

  const cbtn = document.createElement("button");
  cbtn.id = "lms-close";
  cbtn.textContent = "×";
  cbtn.style.display = "none"; // hidden until success/error

  hdr.appendChild(hspan);
  hdr.appendChild(cbtn);

  const body = document.createElement("div");
  body.id = "lms-body";

  lmsPanel.appendChild(hdr);
  lmsPanel.appendChild(body);
  document.body.appendChild(lmsPanel);

  // Drag
  let isDragging = false, offsetX = 0, offsetY = 0;
  hdr.addEventListener("mousedown", (e) => {
    isDragging = true;
    const rect = lmsPanel.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    document.body.style.userSelect = "none";
  });
  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    lmsPanel.style.left  = (e.clientX - offsetX) + "px";
    lmsPanel.style.top   = (e.clientY - offsetY) + "px";
    lmsPanel.style.right = "auto";
  });
  document.addEventListener("mouseup", () => {
    isDragging = false;
    document.body.style.userSelect = "";
  });

  cbtn.onclick = () => { lmsPanel.remove(); lmsPanel = null; };
}

function showConfirm(lessonTitle, grade, subject) {
  createPanel();

  const cbtn = document.getElementById("lms-close");
  if (cbtn) cbtn.style.display = "none";

  const body = document.getElementById("lms-body");
  body.innerHTML = "";
  body.className = "lms-body-confirm";

  const question = document.createElement("p");
  question.className = "lms-confirm-question";
  question.textContent = "هل تريد إنشاء تحضير لهذا الدرس؟";

  const titleEl = document.createElement("p");
  titleEl.className = "lms-confirm-title";
  titleEl.textContent = lessonTitle;

  const btnRow = document.createElement("div");
  btnRow.className = "lms-btn-row";

  const yesBtn = document.createElement("button");
  yesBtn.className = "lms-btn lms-btn-yes";
  yesBtn.textContent = "نعم، أنشئ التحضير";
  yesBtn.onclick = () => { generateLessonPlan(lessonTitle, grade, subject); };

  const noBtn = document.createElement("button");
  noBtn.className = "lms-btn lms-btn-no";
  noBtn.textContent = "لا";
  noBtn.onclick = () => {
    dismissedLesson = lessonTitle;
    lmsPanel.remove();
    lmsPanel = null;
  };

  btnRow.appendChild(yesBtn);
  btnRow.appendChild(noBtn);
  body.appendChild(question);
  body.appendChild(titleEl);
  body.appendChild(btnRow);
}

function showPanel(type, message) {
  createPanel();

  const cbtn = document.getElementById("lms-close");
  if (cbtn) cbtn.style.display = (type === "success" || type === "error") ? "block" : "none";

  const body = document.getElementById("lms-body");
  body.innerHTML = "";
  body.className = "";

  const statusDiv = document.createElement("div");
  statusDiv.className = "lms-status " + type;
  statusDiv.textContent = message;
  body.appendChild(statusDiv);
}

function updatePanel(type, message) { showPanel(type, message); }

function startLoadingTimer(title) {
  if (loadingTimer) clearInterval(loadingTimer);
  let seconds = 0;
  showPanel("loading", `⏳ جاري إنشاء تحضير: ${title} 0s`);
  loadingTimer = setInterval(() => {
    seconds++;
    showPanel("loading", `⏳ جاري إنشاء تحضير: ${title} ${seconds}s`);
  }, 1000);
}

function stopLoadingTimer() {
  if (loadingTimer)  { clearInterval(loadingTimer);  loadingTimer  = null; }
  if (watchdogTimer) { clearInterval(watchdogTimer); watchdogTimer = null; }
}

// ===============================
// MAIN GENERATION — direct fetch
// ===============================

async function generateLessonPlan(lessonTitle, grade, subject) {

  if (isGenerating) return;
  isGenerating = true;

  currentLesson = { lessonTitle, grade, subject };

  if (!lessonTitle || !grade || !subject) {
    showPanel("error", "⚠ بيانات الدرس غير مكتملة.");
    isGenerating = false;
    return;
  }

  const storage = await api.storage.local.get(["user_email", "user_id"]);
  let userEmail = storage.user_email;
  let userId    = storage.user_id;

  if (!userId) {
    userId = crypto.randomUUID();
    await api.storage.local.set({ user_id: userId });
  }

  const deviceFingerprint = await getDeviceFingerprint();

  if (!userEmail) {
    showPanel("error", "افتح نافذة الإضافة وسجّل بريدك الإلكتروني أولاً.");
    isGenerating = false;
    return;
  }

  startLoadingTimer(lessonTitle);

  // Watchdog: auto-retry after 35s
  let watchdogSeconds = 0;
  watchdogTimer = setInterval(() => {
    watchdogSeconds++;
    if (watchdogSeconds >= 35) {
      stopLoadingTimer();
      isGenerating = false;
      if (currentLesson) {
        console.log("Watchdog: auto-retrying...");
        generateLessonPlan(currentLesson.lessonTitle, currentLesson.grade, currentLesson.subject);
      }
    }
  }, 1000);

  try {

    const response = await fetch(
      "https://rznegxkfwwtqkytkoljs.supabase.co/functions/v1/generate-lesson",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": ANON_KEY,
          "Authorization": `Bearer ${ANON_KEY}`,
          "x-extension-secret": "303acfbd-ceaf-4f8f-b458-8a043661db92-96557a86-278a-4568-8e51-05ebb0d52a81"
        },
        body: JSON.stringify({
          user_id:            userId,
          email:              userEmail,
          grade:              grade,
          subject:            subject,
          lessonTitle:        lessonTitle,
          extension_secret:   "303acfbd-ceaf-4f8f-b458-8a043661db92-96557a86-278a-4568-8e51-05ebb0d52a81",
          device_fingerprint: deviceFingerprint
        })
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || "Server error.");
    }

    const responseData = await response.json();
    if (responseData.error) throw new Error(responseData.error);

    stopLoadingTimer();
    distributeSections(responseData.result || "", subject);
    showPanel("success", "✅ تم إنشاء التحضير بنجاح!");

  } catch (error) {
    console.error("Generation error:", error);
    stopLoadingTimer();
    showPanel("error", "⚠ " + (error?.message || "حدث خطأ."));
  } finally {
    isGenerating = false;
  }

}

// ===============================
// DEVICE FINGERPRINTING
// ===============================

async function getDeviceFingerprint() {
  return Promise.race([
    _generateFingerprint(),
    new Promise(resolve => setTimeout(() => resolve("no-fingerprint-timeout"), 3000))
  ]);
}

async function _generateFingerprint() {
  const components = [];
  components.push(navigator.userAgent);
  components.push(`${screen.width}x${screen.height}x${screen.colorDepth}`);
  components.push(Intl.DateTimeFormat().resolvedOptions().timeZone);
  components.push(navigator.language);
  components.push(navigator.platform || "unknown");
  components.push(String(navigator.hardwareConcurrency || 0));

  try {
    const canvas = document.createElement("canvas");
    canvas.width = 200; canvas.height = 50;
    const ctx = canvas.getContext("2d");
    ctx.textBaseline = "top"; ctx.font = "14px Arial";
    ctx.fillStyle = "#f60"; ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = "#069"; ctx.fillText("LMS🎓fingerprint", 2, 15);
    ctx.fillStyle = "rgba(102,204,0,0.7)"; ctx.fillText("LMS🎓fingerprint", 4, 17);
    components.push(canvas.toDataURL());
  } catch(e) { components.push("no-canvas"); }

  try {
    const audioCtx   = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const analyser   = audioCtx.createAnalyser();
    const gain       = audioCtx.createGain();
    gain.gain.value  = 0;
    oscillator.connect(analyser); analyser.connect(gain); gain.connect(audioCtx.destination);
    oscillator.start(0);
    const buffer = new Float32Array(analyser.frequencyBinCount);
    analyser.getFloatFrequencyData(buffer);
    oscillator.stop(); audioCtx.close();
    components.push(buffer.slice(0, 10).join(","));
  } catch(e) { components.push("no-audio"); }

  const raw        = components.join("|||");
  const hashBuffer = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
  return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, "0")).join("");
}

// ===============================
// SECTION EXTRACTOR
// ===============================

function isEnglishContent(text) {
  return /Key Vocabulary\s*:/i.test(text) || /Warm-up\s*[\/:]/.test(text) || /Lesson Procedures\s*:/i.test(text);
}

function getSection(text, start, end) {
  const startIndex = text.indexOf(start);
  if (startIndex === -1) return "";
  const from     = startIndex + start.length;
  let endIndex   = end ? text.indexOf(end, from) : -1;
  if (endIndex === -1) endIndex = text.length;
  return text.substring(from, endIndex).trim();
}

// ===============================
// DISTRIBUTE AI SECTIONS
// ===============================

function distributeSections(fullText, subject) {
  console.log("FULL AI TEXT:", fullText);
  updatePanel("loading", "⏳ جاري ملء الحقول...");

  const isMath = subject && subject.includes("رياضيات");

  waitForEditors(6)
    .then(async (editors) => {
      const english  = isEnglishContent(fullText);
      const sections = english ? {
        vocabulary:  extractSection(fullText, "Key Vocabulary:"),
        preLearning: extractSection(fullText, "Warm-up / Prior Knowledge:"),
        activities:  extractSection(fullText, "Lesson Procedures / Teaching Activities:"),
        formative:   extractSection(fullText, "Formative Assessment:"),
        summative:   extractSection(fullText, "Summative Assessment:"),
        notes:       extractSection(fullText, "Notes:")
      } : {
        vocabulary:  extractSection(fullText, "المفاهيم:"),
        preLearning: extractSection(fullText, "التهيئة / التمهيد / التعلم القبلي:"),
        activities:  extractSection(fullText, "إجراءات سير الدرس / الأنشطة التدريسية:"),
        formative:   extractSection(fullText, "التقويم التكويني:"),
        summative:   extractSection(fullText, "التقويم الختامي:"),
        notes:       extractSection(fullText, "ملاحظات:")
      };

      await injectIntoEditor(editors[0], sections.vocabulary,  english, isMath);
      await injectIntoEditor(editors[1], sections.preLearning, english, isMath);
      await injectIntoEditor(editors[2], sections.activities,  english, isMath);
      await injectIntoEditor(editors[3], sections.formative,   english, isMath);
      await injectIntoEditor(editors[4], sections.summative,   english, isMath);
      await injectIntoEditor(editors[5], sections.notes,       english, isMath);
      console.log("All sections injected.");
    })
    .catch(() => {
      updatePanel("error", "⚠ لم تُحمَّل حقول التحرير. حاول النقر على الدرس مرة أخرى.");
    });
}

// ===============================
// INJECT INTO EDITOR
// ===============================

// ===============================
// PURE CSS MATH RENDERER
// Converts LaTeX → styled HTML — no external dependencies
// ===============================

function latexToHTML(latex) {
  let s = latex.trim();
  const tokens = [];

  function protect(html) {
    tokens.push(html);
    return `⟨${tokens.length - 1}⟩`;
  }

  function varSpan(t) {
    return `<span style="color:#166534;font-weight:bold;font-family:'Noto Kufi Arabic',sans-serif;">${t}</span>`;
  }
  function fracHTML(n, d) {
    return `<span style="display:inline-flex;flex-direction:column;align-items:center;vertical-align:middle;margin:0 3px;font-size:0.88em;"><span style="border-bottom:1.5px solid currentColor;padding:0 4px;text-align:center;">${n}</span><span style="padding:0 4px;text-align:center;">${d}</span></span>`;
  }
  function binomHTML(n, k) {
    return `<span style="display:inline-flex;align-items:center;vertical-align:middle;margin:0 2px;"><span style="font-size:1.8em;line-height:1;font-weight:200;">(</span><span style="display:inline-flex;flex-direction:column;align-items:center;font-size:0.82em;margin:0 2px;"><span style="padding:1px 3px;text-align:center;">${n}</span><span style="padding:1px 3px;text-align:center;">${k}</span></span><span style="font-size:1.8em;line-height:1;font-weight:200;">)</span></span>`;
  }
  function supHTML(base, exp) {
    return `${base}<sup style="font-size:0.72em;vertical-align:super;line-height:0;">${exp}</sup>`;
  }
  function subHTML(base, sub) {
    return `${base}<sub style="font-size:0.72em;vertical-align:sub;line-height:0;">${sub}</sub>`;
  }
  function sqrtHTML(c) {
    return `<span style="border-top:1.5px solid currentColor;padding:1px 3px 0 2px;"><span style="font-size:1.05em;">√</span>${c}</span>`;
  }

  // Step 1: \text{} → protected span
  s = s.replace(/\\text\{([^}]*)\}/g, (_, t) => protect(varSpan(t)));

  // Step 2: structural — multiple passes for nesting
  for (let pass = 0; pass < 5; pass++) {
    s = s.replace(/\\d?frac\{([^{}]*)\}\{([^{}]*)\}/g,
      (_, n, d) => protect(fracHTML(n, d)));
  }
  for (let pass = 0; pass < 5; pass++) {
    s = s.replace(/\\binom\{([^{}]*)\}\{([^{}]*)\}/g,
      (_, n, k) => protect(binomHTML(n, k)));
  }
  s = s.replace(/\\sqrt\{([^{}]*)\}/g, (_, c) => protect(sqrtHTML(c)));

  // Step 3: symbol substitutions
  s = s.replace(/\\times/g, '×');
  s = s.replace(/\\div/g, '÷');
  s = s.replace(/\\cdot/g, '·');
  s = s.replace(/\\pm/g, '±');
  s = s.replace(/\\neq/g, '≠');
  s = s.replace(/\\leq/g, '≤');
  s = s.replace(/\\geq/g, '≥');
  s = s.replace(/\\infty/g, '∞');
  s = s.replace(/\\Rightarrow/g, ' ⟹ ');
  s = s.replace(/\\rightarrow/g, ' → ');
  s = s.replace(/\\iff|\\Longleftrightarrow/g, ' ⟺ ');
  s = s.replace(/\\dots|\\ldots/g, '…');
  s = s.replace(/\\sum/g, 'Σ');
  s = s.replace(/\\quad/g, '\u2003');
  s = s.replace(/\\left\(|\\right\)/g, '');
  s = s.replace(/\\left\[|\\right\]/g, '');
  s = s.replace(/\\left|\\right/g, '');
  s = s.replace(/\\[a-zA-Z]+/g, '');
  // NOTE: braces removed AFTER sup/sub step

  // Step 4: sup/sub — base can be token, parenthesized group, or chars
  s = s.replace(/(⟨\d+⟩|\([^)]*\)|[٠-٩أ-يa-zA-Z]+)\^\{([^}]*)\}/g,
    (_, base, exp) => protect(supHTML(base, exp)));
  s = s.replace(/(⟨\d+⟩|\([^)]*\)|[٠-٩أ-يa-zA-Z]+)_\{([^}]*)\}/g,
    (_, base, sub) => protect(subHTML(base, sub)));

  // Now remove remaining braces
  s = s.replace(/[{}]/g, '');

  // Step 5: wrap Eastern Arabic numbers (tokens are protected by ⟨⟩)
  s = s.replace(/(?<![⟩\d])([٠-٩]+(?:[.,][٠-٩]+)?)(?![⟨\d])/g,
    (_, n) => protect(`<span style="font-family:'Times New Roman',serif;">${n}</span>`));

  // Step 6: operator spacing
  s = s.replace(/\s*([=+])\s*/g, ' $1 ');

  // Step 7: resolve tokens (loop handles nesting)
  let prev = '';
  while (prev !== s) {
    prev = s;
    s = s.replace(/⟨(\d+)⟩/g, (_, i) => tokens[parseInt(i)]);
  }

  return `<span style="font-family:'Times New Roman',serif;color:#166534;font-weight:bold;direction:ltr;unicode-bidi:embed;display:inline;">${s}</span>`;
}

function renderMath(text, isMath) {
  if (!isMath) {
    // Non-math: strip $$ and clean LaTeX
    return text.replace(/\$\$([^$]+)\$\$/g, (_, expr) =>
      expr.trim()
        .replace(/\\text\{([^}]*)\}/g, "$1")
        .replace(/\\[a-zA-Z]+/g, "")
        .replace(/[{}]/g, "")
    );
  }

  // Math: convert each $$ block to styled HTML
  return text.replace(/\$\$([^$]+)\$\$/g, (_, expr) => latexToHTML(expr));
}



function renderWithKaTeX(doc, text, isMath = false) {
  // Convert Western digits → Eastern Arabic ONLY for math subjects
  if (isMath) {
    text = text.replace(/[0-9]/g, d => "٠١٢٣٤٥٦٧٨٩"[d]);
  }

  // Unicode superscripts → Eastern Arabic superscripts (math only)
  if (isMath) {
    const supMap = {"⁰":"٠","¹":"١","²":"٢","³":"٣","⁴":"٤","⁵":"٥","⁶":"٦","⁷":"٧","⁸":"٨","⁹":"٩"};
    text = text.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]+/g, m =>
      `<sup>${m.split("").map(c => supMap[c]||c).join("")}</sup>`);
  }

  // Sub-headings (أولاً، ثانياً ...) → red bold
  text = text.replace(
    /^((?:أولاً|ثانياً|ثالثاً|رابعاً|خامساً|سادساً|سابعاً|ثامناً|تاسعاً|عاشراً)[^\n]*)$/gm,
    '<span class="lms-sub">$1</span>'
  );

  // Section headers bold
  text = text.replace(/المفاهيم:/g,           "<strong>المفاهيم:</strong><br>");
  text = text.replace(/التهيئة \/ التمهيد \/ التعلم القبلي:/g, "<strong>التهيئة / التمهيد / التعلم القبلي:</strong><br>");
  text = text.replace(/إجراءات سير الدرس \/ الأنشطة التدريسية:/g, "<strong>إجراءات سير الدرس / الأنشطة التدريسية:</strong><br>");
  text = text.replace(/التقويم التكويني:/g,    "<strong>التقويم التكويني:</strong><br>");
  text = text.replace(/التقويم الختامي:/g,     "<strong>التقويم الختامي:</strong><br>");
  text = text.replace(/ملاحظات:/g,             "<strong>ملاحظات:</strong><br>");
  text = text.replace(/Key Vocabulary:/g,      "<strong>Key Vocabulary:</strong><br>");
  text = text.replace(/Warm-up \/ Prior Knowledge:/g, "<strong>Warm-up / Prior Knowledge:</strong><br>");
  text = text.replace(/Lesson Procedures \/ Teaching Activities:/g, "<strong>Lesson Procedures / Teaching Activities:</strong><br>");
  text = text.replace(/Formative Assessment:/g, "<strong>Formative Assessment:</strong><br>");
  text = text.replace(/Summative Assessment:/g, "<strong>Summative Assessment:</strong><br>");
  text = text.replace(/Notes:/g,               "<strong>Notes:</strong><br>");

  text = text.replace(/\n/g, "<br>").replace(/(<br>\s*){3,}/g, "<br><br>");
  return text;
}

async function injectIntoEditor(iframe, content, isEnglish = false, isMath = false) {
  if (!content) return;
  const doc = iframe.contentDocument || iframe.contentWindow.document;
  if (!doc || !doc.body) return;

  // Inject our styles
  if (!doc.getElementById("lms-math-styles")) {
    const styleEl = doc.createElement("style");
    styleEl.id = "lms-math-styles";
    styleEl.textContent = mathStyles;
    (doc.head || doc.documentElement).appendChild(styleEl);
  }

  // Strip markdown artifacts
  content = content.replace(/###/g, "").replace(/\*\*/g, "");

  // Render $$ blocks to styled HTML FIRST
  const withMath = renderMath(content, isMath);

  // Apply section headers, subheadings, \n→<br>
  // Pass isMath=false to renderWithKaTeX to skip digit conversion
  // (digits inside $$ were already handled by renderMath, and HTML must not be corrupted)
  const processed = renderWithKaTeX(doc, withMath, false);

  const html = isEnglish
    ? `<div style="direction:ltr;text-align:left;">${processed}</div>`
    : `<div style="direction:rtl;text-align:right;font-family:'Noto Kufi Arabic',sans-serif;line-height:2;">${processed}</div>`;
  const parsed = new doc.defaultView.DOMParser().parseFromString(`<body>${html}</body>`, "text/html");
  doc.body.replaceChildren(...Array.from(parsed.body.childNodes).map(n => doc.adoptNode(n)));
  doc.body.dispatchEvent(new Event("input", { bubbles: true }));
}


